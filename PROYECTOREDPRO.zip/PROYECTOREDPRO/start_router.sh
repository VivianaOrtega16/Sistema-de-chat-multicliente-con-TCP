#!/bin/bash

# Script para iniciar un Router

echo "=========================================="
echo "  Iniciando Router"
echo "=========================================="
echo ""

# Verificar argumento (router_id)
if [ $# -eq 0 ]; then
    echo "Uso: ./start_router.sh <router_id>"
    echo "Ejemplo: ./start_router.sh R1"
    exit 1
fi

ROUTER_ID=$1

# Verificar que estamos en el directorio correcto
if [ ! -d "router" ]; then
    echo "Error: Directorio router no encontrado"
    echo "Ejecuta este script desde el directorio raíz del proyecto"
    exit 1
fi

# Verificar que existe el archivo de configuración
if [ ! -f "router/config.json" ]; then
    echo "Error: router/config.json no encontrado"
    echo "Crea el archivo de configuración primero"
    exit 1
fi

# Verificar que existe main.py
if [ ! -f "router/main.py" ]; then
    echo "Error: router/main.py no encontrado"
    exit 1
fi

# Actualizar el router_id en config.json
echo "Configurando router_id: $ROUTER_ID"
python3 -c "
import json
with open('router/config.json', 'r') as f:
    config = json.load(f)
config['router']['router_id'] = '$ROUTER_ID'
with open('router/config.json', 'w') as f:
    json.dump(config, f, indent=2)
print('✓ Router ID configurado')
"

# Cambiar al directorio del router
cd router

# Verificar conexión a la base de datos
echo "Verificando conexión a la base de datos..."
python3 -c "
import json
import mysql.connector
try:
    with open('config.json') as f:
        config = json.load(f)
    db_config = config['database']
    conn = mysql.connector.connect(
        host=db_config['host'],
        user=db_config['user'],
        password=db_config['password'],
        database=db_config['database']
    )
    conn.close()
    print('✓ Conexión a la base de datos exitosa')
except Exception as e:
    print(f'✗ Error de conexión: {e}')
    exit(1)
" || exit 1

echo ""
echo "Iniciando Router $ROUTER_ID..."
echo ""

# Ejecutar el Router
python3 main.py