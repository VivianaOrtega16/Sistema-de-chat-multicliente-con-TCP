"""
Test de conectividad para el proyecto SDN.
Verifica que las bases de datos y el protocolo funcionen correctamente.
"""

import json
import os
import sys


# ================================
# 1. PROBAR BASES DE DATOS
# ================================

def test_db(config_path):
    """Prueba la conexión a una base de datos usando su config.json"""
    print(f"\n🗄️  Probando DB: {config_path}")

    if not os.path.exists(config_path):
        print(f"   ✗ No se encuentra {config_path}")
        return False

    try:
        with open(config_path, 'r') as f:
            config = json.load(f)

        db_config = config.get('database', {})

        import mysql.connector
        conn = mysql.connector.connect(
            host=db_config.get('host', 'localhost'),
            user=db_config.get('user', 'root'),
            password=db_config.get('password', ''),
            database=db_config.get('database', '')
        )

        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()
        cursor.close()
        conn.close()

        print("   ✓ Conexión a DB exitosa")
        return True

    except Exception as e:
        print(f"   ✗ Error conectando a DB: {e}")
        return False


# ================================
# 2. PROBAR IMPORT DEL PROTOCOLO
# ================================

def test_protocol():
    print("\n📦 Probando importación del protocolo...")

    try:
        # CORRECCIÓN: Importar desde los módulos correctos
        from protocol.message import build_message, parse_message
        from protocol.constants import MessageType

        print("   ✓ Protocolo importado correctamente")

        # Construir mensaje simple
        msg = build_message(
            msg_type=MessageType.ROUTER_CONNECTED,
            payload_dict={"router_id": "TEST", "port": 5000}
        )
        print(f"   ✓ Mensaje construido: {len(msg)} bytes")

        # Parsear el mensaje
        parsed = parse_message(msg)
        print(f"   ✓ Mensaje parseado correctamente")
        print(f"      - Tipo: {parsed['type']} (ROUTER_CONNECTED)")
        print(f"      - Payload: {parsed['payload']}")

        # Verificar que el contenido sea correcto
        assert parsed['type'] == MessageType.ROUTER_CONNECTED
        assert parsed['payload']['router_id'] == "TEST"
        assert parsed['payload']['port'] == 5000

        print("   ✓ Validación de contenido exitosa")

        return True

    except ImportError as e:
        print(f"   ✗ Error importando protocolo: {e}")
        print("   Tip: Asegúrate de que la carpeta 'protocol/' existe")
        return False
    except Exception as e:
        print(f"   ✗ Error probando protocolo: {e}")
        import traceback
        traceback.print_exc()
        return False


# ================================
# 3. MAIN
# ================================

def main():
    print("=" * 60)
    print(" SDN PROJECT — TEST DE CONECTIVIDAD")
    print("=" * 60)

    ok_brain = test_db("brain_controller/config.json")
    ok_router = test_db("router/config.json")
    ok_proto = test_protocol()

    print("\n" + "=" * 60)
    print(" RESULTADO")
    print("=" * 60)

    print("Brain DB  :", "✓ OK" if ok_brain else "✗ FAIL")
    print("Router DB :", "✓ OK" if ok_router else "✗ FAIL")
    print("Protocolo :", "✓ OK" if ok_proto else "✗ FAIL")

    if ok_brain and ok_router and ok_proto:
        print("\n🎉 TODO CORRECTO — El proyecto está listo para correr.")
        return 0
    else:
        print("\n⚠️  Hay errores. Revisa las configuraciones.")
        return 1


if __name__ == "__main__":
    sys.exit(main())