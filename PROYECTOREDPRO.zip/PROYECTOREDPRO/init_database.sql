-- Script de inicialización de bases de datos para SDN Project
-- Ejecutar como: mysql -u root -p < init_database.sql

-- ========================================
-- CONTROLLERDB - Base de datos del Brain
-- ========================================

DROP DATABASE IF EXISTS controllerdb;
CREATE DATABASE controllerdb;
USE controllerdb;

-- Tabla controller: información del controlador
CREATE TABLE IF NOT EXISTS controller (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    ip_address VARCHAR(45),
    port INT,
    status VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabla router: routers gestionados por el controlador
CREATE TABLE IF NOT EXISTS router (
    router_id VARCHAR(50) PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    port INT NOT NULL,
    status VARCHAR(20) DEFAULT 'disconnected',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabla links: enlaces entre routers
CREATE TABLE IF NOT EXISTS links (
    link_id VARCHAR(50) PRIMARY KEY,
    source_router_id VARCHAR(50) NOT NULL,
    destination_router_id VARCHAR(50) NOT NULL,
    cost INT DEFAULT 1,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (source_router_id) REFERENCES router(router_id) ON DELETE CASCADE,
    FOREIGN KEY (destination_router_id) REFERENCES router(router_id) ON DELETE CASCADE
);

-- Tabla route_calculate: rutas calculadas por Dijkstra
CREATE TABLE IF NOT EXISTS route_calculate (
    id INT AUTO_INCREMENT PRIMARY KEY,
    router_id VARCHAR(50) NOT NULL,
    destination_router_id VARCHAR(50) NOT NULL,
    next_hop_router_id VARCHAR(50) NOT NULL,
    cost INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (router_id) REFERENCES router(router_id) ON DELETE CASCADE
);

-- Índices para mejorar rendimiento
CREATE INDEX idx_router_status ON router(status);
CREATE INDEX idx_links_status ON links(status);
CREATE INDEX idx_links_source ON links(source_router_id);
CREATE INDEX idx_links_destination ON links(destination_router_id);
CREATE INDEX idx_route_router ON route_calculate(router_id);
CREATE INDEX idx_route_destination ON route_calculate(destination_router_id);

SELECT 'Base de datos controllerdb creada exitosamente' AS status;

-- ========================================
-- ROUTERDB - Base de datos de los Routers
-- ========================================

DROP DATABASE IF EXISTS routerdb;
CREATE DATABASE routerdb;
USE routerdb;

-- Tabla router: información del router local
CREATE TABLE IF NOT EXISTS router (
    router_id VARCHAR(50) PRIMARY KEY,
    ip_address VARCHAR(45),
    port INT,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabla host: hosts conectados al router
CREATE TABLE IF NOT EXISTS host (
    host_id VARCHAR(50) PRIMARY KEY,
    router_id VARCHAR(50) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    mac_address VARCHAR(17),
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (router_id) REFERENCES router(router_id) ON DELETE CASCADE
);

-- Tabla route: tabla de enrutamiento del router
CREATE TABLE IF NOT EXISTS route (
    id INT AUTO_INCREMENT PRIMARY KEY,
    router_id VARCHAR(50) NOT NULL,
    destination_router_id VARCHAR(50) NOT NULL,
    next_hop_router_id VARCHAR(50) NOT NULL,
    cost INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (router_id) REFERENCES router(router_id) ON DELETE CASCADE
);

-- Índices para mejorar rendimiento
CREATE INDEX idx_host_router ON host(router_id);
CREATE INDEX idx_route_router ON route(router_id);
CREATE INDEX idx_route_destination ON route(destination_router_id);

SELECT 'Base de datos routerdb creada exitosamente' AS status;

-- ========================================
-- Datos de ejemplo (opcional)
-- ========================================

-- Insertar datos de ejemplo en controllerdb
USE controllerdb;

INSERT INTO controller (name, ip_address, port, status) VALUES
('BrainController1', '0.0.0.0', 9000, 'active');

-- Insertar datos de ejemplo en routerdb
USE routerdb;

-- No insertamos datos aquí porque cada router tendrá su propia instancia

-- ========================================
-- Verificación
-- ========================================

USE controllerdb;
SELECT 'Tablas en controllerdb:' AS info;
SHOW TABLES;

USE routerdb;
SELECT 'Tablas en routerdb:' AS info;
SHOW TABLES;

SELECT '¡Bases de datos inicializadas correctamente!' AS status;