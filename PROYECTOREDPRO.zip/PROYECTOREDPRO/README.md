# Proyecto SDN - Brain Controller y Router

Sistema de red definida por software (SDN) con arquitectura MVC que implementa un controlador centralizado (Brain) y routers distribuidos que se comunican mediante un protocolo personalizado.

## 📋 Tabla de Contenidos

- [Características](#características)
- [Arquitectura](#arquitectura)
- [Requisitos](#requisitos)
- [Instalación](#instalación)
- [Configuración de Base de Datos](#configuración-de-base-de-datos)
- [Configuración](#configuración)
- [Uso](#uso)
- [Protocolo de Comunicación](#protocolo-de-comunicación)
- [Estructura del Proyecto](#estructura-del-proyecto)
- [Troubleshooting](#troubleshooting)

## 🚀 Características

### Brain Controller
- ✅ Gestión centralizada de topología de red
- ✅ Algoritmo de Dijkstra para cálculo de rutas óptimas
- ✅ Servidor TCP para comunicación con routers
- ✅ Persistencia en base de datos MySQL (controllerdb)
- ✅ CLI interactiva para administración
- ✅ Dashboard web opcional con Dash (visualización)
- ✅ Manejo de eventos: conexión/desconexión de routers, creación/eliminación de enlaces

### Router
- ✅ Cliente TCP para comunicación con Brain Controller
- ✅ Tabla de enrutamiento dinámica
- ✅ Persistencia de rutas en base de datos MySQL (routerdb)
- ✅ CLI interactiva para gestión local
- ✅ Soporte para múltiples vecinos
- ✅ Mensajes HELLO periódicos

## 🏗️ Arquitectura
```
┌─────────────────────────────────────────────────────────────┐
│                      BRAIN CONTROLLER                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │    Model     │  │  Controller  │  │     View     │      │
│  │  - Topology  │  │  - Brain     │  │    - CLI     │      │
│  │  - Router    │  │  - Dijkstra  │  │  - Dash App  │      │
│  │  - Link      │  │  - Socket    │  │              │      │
│  │  - DAO       │  │  - Messages  │  │              │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│         ▲                  │                                 │
│         │                  │                                 │
│         └──────────┬───────┘                                 │
│                    │                                         │
│              controllerdb                                    │
└────────────────────┼─────────────────────────────────────────┘
                     │ TCP
                     │ Port 9000
                     │
    ┌────────────────┼────────────────┬────────────────────┐
    │                │                │                    │
┌───▼────────────────▼───┐   ┌───────▼────────┐   ┌──────▼──────┐
│      ROUTER R1         │   │   ROUTER R2    │   │  ROUTER R3  │
│  ┌────────┬──────────┐ │   │ ┌────────────┐ │   │ ┌─────────┐ │
│  │ Model  │Controller│ │   │ │Model+Ctrl  │ │   │ │Model+...│ │
│  │  - RT  │  - RC    │ │   │ │    - RT    │ │   │ │   - RT  │ │
│  │  - DAO │  - Socket│ │   │ │    - DAO   │ │   │ │   - DAO │ │
│  └────────┴──────────┘ │   │ └────────────┘ │   │ └─────────┘ │
│       routerdb         │   │    routerdb    │   │  routerdb   │
└────────────────────────┘   └────────────────┘   └─────────────┘
```

## 📦 Requisitos

### Software
- Python 3.8 o superior
- MySQL Server 5.7 o superior
- pip (gestor de paquetes de Python)

### Librerías Python
```
mysql-connector-python==8.0.33
dash==2.14.0
plotly==5.17.0
```

## 🔧 Instalación

### 1. Clonar o descargar el proyecto
```bash
# Crear estructura de directorios
mkdir sdn_project
cd sdn_project
```

### 2. Crear estructura de carpetas
```bash
# Brain Controller
mkdir -p brain_controller/model/dao
mkdir -p brain_controller/controller
mkdir -p brain_controller/view

# Router
mkdir -p router/model/dao
mkdir -p router/controller
mkdir -p router/view

# Protocolo (debe estar en la raíz o nivel superior)
mkdir -p protocol
```

### 3. Copiar archivos

Copia todos los archivos generados en los mensajes anteriores a sus respectivas carpetas.

### 4. Instalar dependencias
```bash
pip install mysql-connector-python==8.0.33
pip install dash==2.14.0
pip install plotly==5.17.0
```

O usando requirements.txt:
```bash
pip install -r requirements.txt
```

## 🗄️ Configuración de Base de Datos

### 1. Crear las bases de datos

Ejecuta el script SQL `ControllerRouter.sql`:
```bash
mysql -u root -p < ControllerRouter.sql
```

O manualmente:
```sql
-- Crear base de datos del controlador
CREATE DATABASE IF NOT EXISTS controllerdb;
USE controllerdb;

CREATE TABLE IF NOT EXISTS controller (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    ip_address VARCHAR(45),
    port INT,
    status VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS router (
    router_id VARCHAR(50) PRIMARY KEY,
    ip_address VARCHAR(45),
    port INT,
    status VARCHAR(20) DEFAULT 'disconnected'
);

CREATE TABLE IF NOT EXISTS links (
    link_id VARCHAR(50) PRIMARY KEY,
    source_router_id VARCHAR(50),
    destination_router_id VARCHAR(50),
    cost INT DEFAULT 1,
    status VARCHAR(20) DEFAULT 'active',
    FOREIGN KEY (source_router_id) REFERENCES router(router_id),
    FOREIGN KEY (destination_router_id) REFERENCES router(router_id)
);

CREATE TABLE IF NOT EXISTS route_calculate (
    id INT AUTO_INCREMENT PRIMARY KEY,
    router_id VARCHAR(50),
    destination_router_id VARCHAR(50),
    next_hop_router_id VARCHAR(50),
    cost INT,
    FOREIGN KEY (router_id) REFERENCES router(router_id)
);

-- Crear base de datos del router
CREATE DATABASE IF NOT EXISTS routerdb;
USE routerdb;

CREATE TABLE IF NOT EXISTS router (
    router_id VARCHAR(50) PRIMARY KEY,
    ip_address VARCHAR(45),
    port INT,
    status VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS host (
    host_id VARCHAR(50) PRIMARY KEY,
    router_id VARCHAR(50),
    ip_address VARCHAR(45),
    mac_address VARCHAR(17),
    FOREIGN KEY (router_id) REFERENCES router(router_id)
);

CREATE TABLE IF NOT EXISTS route (
    id INT AUTO_INCREMENT PRIMARY KEY,
    router_id VARCHAR(50),
    destination_router_id VARCHAR(50),
    next_hop_router_id VARCHAR(50),
    cost INT,
    FOREIGN KEY (router_id) REFERENCES router(router_id)
);
```

### 2. Verificar las tablas
```sql
-- Verificar controllerdb
USE controllerdb;
SHOW TABLES;

-- Verificar routerdb
USE routerdb;
SHOW TABLES;
```

## ⚙️ Configuración

### Brain Controller - config.json

Edita `brain_controller/config.json`:
```json
{
  "server": {
    "host": "0.0.0.0",
    "tcp_port": 9000,
    "udp_port": 9001
  },
  "database": {
    "host": "localhost",
    "user": "root",
    "password": "TU_PASSWORD_MYSQL",
    "database": "controllerdb"
  },
  "enable_dash": false,
  "dash": {
    "host": "0.0.0.0",
    "port": 8050
  }
}
```

### Router - config.json

Para cada router, edita `router/config.json`:

**Router R1:**
```json
{
  "router": {
    "router_id": "R1",
    "port": 5001
  },
  "brain_controller": {
    "host": "127.0.0.1",
    "tcp_port": 9000,
    "udp_port": 9001
  },
  "database": {
    "host": "localhost",
    "user": "root",
    "password": "TU_PASSWORD_MYSQL",
    "database": "routerdb"
  }
}
```

**Router R2:**
```json
{
  "router": {
    "router_id": "R2",
    "port": 5002
  },
  "brain_controller": {
    "host": "127.0.0.1",
    "tcp_port": 9000
  },
  "database": {
    "host": "localhost",
    "user": "root",
    "password": "TU_PASSWORD_MYSQL",
    "database": "routerdb"
  }
}
```

## 🎮 Uso

### 1. Iniciar el Brain Controller
```bash
cd brain_controller
python main.py
```

Deberías ver:
```
============================================================
Iniciando Brain Controller
============================================================
2024-XX-XX XX:XX:XX - INFO - Conectado a la base de datos controllerdb
2024-XX-XX XX:XX:XX - INFO - BrainController inicializado correctamente
2024-XX-XX XX:XX:XX - INFO - Servidor TCP iniciado en 0.0.0.0:9000
============================================================
           BRAIN CONTROLLER - SDN
============================================================
Comandos disponibles:
  status        - Ver estado de la topología
  routers       - Listar routers
  links         - Listar enlaces
  routes <id>   - Ver rutas de un router
  recalculate   - Recalcular todas las rutas
  help          - Mostrar esta ayuda
  exit          - Salir
============================================================

Brain>
```

### 2. Iniciar Routers

En terminales separadas:

**Terminal 2 - Router R1:**
```bash
cd router
python main.py
```

**Terminal 3 - Router R2:**
```bash
# Primero modifica config.json para R2
cd router
python main.py
```

**Terminal 4 - Router R3:**
```bash
# Primero modifica config.json para R3
cd router
python main.py
```

### 3. Comandos del Brain Controller
```bash
# Ver estado general
Brain> status

# Ver routers conectados
Brain> routers

# Ver enlaces de la topología
Brain> links

# Ver rutas de un router específico
Brain> routes R1

# Recalcular todas las rutas
Brain> recalculate
```

### 4. Comandos del Router
```bash
# Ver estado del router
Router[R1]> status

# Ver tabla de enrutamiento
Router[R1]> routes

# Ver vecinos
Router[R1]> neighbors

# Enviar HELLO al Brain
Router[R1]> hello

# Crear un enlace (link_id, destino, costo)
Router[R1]> link link_R1_R2 R2 10

# Eliminar un enlace
Router[R1]> dellink link_R1_R2
```

## 📡 Protocolo de Comunicación

### Mensajes Implementados

| ID   | Nombre              | Dirección      | Descripción                          |
|------|---------------------|----------------|--------------------------------------|
| 0x01 | ROUTER_CONNECTED    | Router → Brain | Router se conecta al controlador     |
| 0x02 | ROUTER_DISCONNECTED | Router → Brain | Router se desconecta                 |
| 0x03 | CREATE_LINK         | Router → Brain | Crear enlace entre routers           |
| 0x04 | DELETE_LINK         | Router → Brain | Eliminar enlace                      |
| 0x05 | HELLO               | Router → Brain | Mensaje de keepalive                 |
| 0x06 | ACK_CONNECTED       | Brain → Router | Confirmación de conexión             |
| 0x07 | ROUTE_UPDATE        | Brain → Router | Actualización de tabla de rutas      |
| 0x08 | ACK_ROUTE           | Router → Brain | Confirmación de rutas recibidas      |
| 0x10 | ACK_GENERIC         | Brain → Router | Confirmación genérica                |

### Flujo de Operación
```
1. CONEXIÓN
   Router ─[ROUTER_CONNECTED]→ Brain
   Router ←[ACK_CONNECTED]───── Brain

2. CREACIÓN DE ENLACE
   Router ─[CREATE_LINK]────→ Brain
   Brain ejecuta Dijkstra
   Router ←[ROUTE_UPDATE]───── Brain
   Router ─[ACK_ROUTE]──────→ Brain

3. HELLO PERIÓDICO
   Router ─[HELLO]──────────→ Brain
   Router ←[ACK_GENERIC]────── Brain

4. DESCONEXIÓN
   Router ─[ROUTER_DISCONNECTED]→ Brain
   Router ←[ACK_GENERIC]────────── Brain
```

## 📁 Estructura del Proyecto
```
sdn_project/
│
├── protocol/                    # Paquete de protocolo (NO MODIFICAR)
│   ├── __init__.py
│   ├── constants.py
│   ├── message.py
│   └── utils.py
│
├── brain_controller/
│   ├── config.json
│   ├── main.py
│   ├── model/
│   │   ├── __init__.py
│   │   ├── topology.py
│   │   ├── router.py
│   │   ├── link.py
│   │   ├── routing_table.py
│   │   └── dao/
│   │       ├── __init__.py
│   │       ├── database.py
│   │       ├── router_dao.py
│   │       ├── link_dao.py
│   │       └── route_dao.py
│   ├── controller/
│   │   ├── __init__.py
│   │   ├── brain_controller.py
│   │   ├── dijkstra.py
│   │   ├── socket_server.py
│   │   └── message_handler.py
│   └── view/
│       ├── __init__.py
│       ├── cli.py
│       └── dash_app.py
│
└── router/
    ├── config.json
    ├── main.py
    ├── model/
    │   ├── __init__.py
    │   ├── routing_table.py
    │   ├── neighbor.py
    │   └── dao/
    │       ├── __init__.py
    │       ├── database.py
    │       └── routing_dao.py
    ├── controller/
    │   ├── __init__.py
    │   ├── router_controller.py
    │   ├── socket_client.py
    │   └── message_handler.py
    └── view/
        ├── __init__.py
        └── router_cli.py
```

## 🔍 Troubleshooting

### Error: "Can't connect to MySQL server"

**Problema:** No se puede conectar a la base de datos.

**Solución:**
```bash
# Verificar que MySQL está corriendo
sudo systemctl status mysql

# Iniciar MySQL si está detenido
sudo systemctl start mysql

# Verificar credenciales en config.json
```

### Error: "Address already in use"

**Problema:** El puerto TCP 9000 ya está en uso.

**Solución:**
```bash
# Encontrar proceso usando el puerto
lsof -i :9000

# Matar el proceso
kill -9 <PID>

# O cambiar el puerto en config.json
```

### Error: "ModuleNotFoundError: No module named 'protocol'"

**Problema:** Python no encuentra el paquete protocol.

**Solución:**
```bash
# Asegúrate de que protocol/ está en la ruta correcta
# Opción 1: Ejecutar desde el directorio padre
cd sdn_project
python brain_controller/main.py

# Opción 2: Agregar al PYTHONPATH
export PYTHONPATH="${PYTHONPATH}:/ruta/a/sdn_project"
```

### Router no se conecta al Brain

**Problema:** El router no puede conectarse al Brain Controller.

**Solución:**
1. Verificar que el Brain está corriendo
2. Verificar IP y puerto en `router/config.json`
3. Verificar firewall:
```bash
sudo ufw allow 9000/tcp
```

### Las rutas no se calculan

**Problema:** Después de crear enlaces, no se generan rutas.

**Solución:**
1. Verificar que ambos routers están conectados
2. Verificar que el enlace se creó correctamente:
```bash
Brain> links
```
3. Forzar recálculo:
```bash
Brain> recalculate
```

### Dashboard no se visualiza

**Problema:** Dash app no carga.

**Solución:**
1. Habilitar en `config.json`:
```json
"enable_dash": true
```
2. Verificar que Dash está instalado:
```bash
pip install dash plotly
```
3. Acceder a: `http://localhost:8050`

## 📝 Ejemplo de Uso Completo

### Escenario: Topología con 3 routers
```
    R1 ────(10)──── R2
     │              │
    (5)           (15)
     │              │
     └──── R3 ──────┘
           (8)
```

**Paso 1:** Iniciar Brain
```bash
cd brain_controller
python main.py
```

**Paso 2:** Iniciar R1
```bash
# Terminal 2
cd router
# Editar config.json con router_id: "R1"
python main.py
```

**Paso 3:** Iniciar R2
```bash
# Terminal 3
cd router
# Editar config.json con router_id: "R2"
python main.py
```

**Paso 4:** Iniciar R3
```bash
# Terminal 4
cd router
# Editar config.json con router_id: "R3"
python main.py
```

**Paso 5:** Crear enlaces desde R1
```bash
Router[R1]> link link_R1_R2 R2 10
Router[R1]> link link_R1_R3 R3 5
```

**Paso 6:** Crear enlaces desde R2
```bash
Router[R2]> link link_R2_R3 R3 15
```

**Paso 7:** Ver rutas calculadas
```bash
# En el Brain
Brain> routes R1
Brain> routes R2
Brain> routes R3
```

**Resultado esperado:**
- R1 puede llegar a R2 directamente (costo 10) o vía R3 (costo 13)
- R1 elige la ruta directa a R2 (costo 10)
- R2 puede llegar a R3 directamente (costo 15) o vía R1 (costo 15)
- Ambas rutas tienen el mismo costo

## 🎯 Próximos Pasos

1. ✅ Sistema completamente funcional
2. 🔄 Agregar soporte para UDP (mensajes HELLO)
3. 🔄 Implementar detección de fallos de enlaces
4. 🔄 Mejorar visualización de topología en Dash
5. 🔄 Agregar métricas de rendimiento
6. 🔄 Implementar balanceo de carga

## 📄 Licencia

Este proyecto es parte de un trabajo académico.

## 👥 Contribuciones

Proyecto desarrollado como parte del curso de Redes de Computadores.

## 📧 Soporte

Para problemas o preguntas, revisar la sección de Troubleshooting o consultar la documentación del protocolo.
```

------------------------------------
Archivo: requirements.txt
------------------------------------
```
mysql-connector-python==8.0.33
dash==2.14.0
plotly==5.17.0