"""
Módulo de modelos para el Router.
Contiene las clases de dominio: RoutingTable, Neighbor.
"""

from .routing_table import RoutingTable
from .neighbor import Neighbor

__all__ = ['RoutingTable', 'Neighbor']