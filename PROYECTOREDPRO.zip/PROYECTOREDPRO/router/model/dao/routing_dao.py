"""
RoutingDAO: acceso a datos para la tabla 'route' en routerdb.
"""

import logging

logger = logging.getLogger(__name__)

class RoutingDAO:
    def __init__(self, database):
        self.db = database
    
    def create(self, router_id, destination_router_id, next_hop_router_id, cost):
        query = """
        INSERT INTO route (router_id, destination_router_id, next_hop_router_id, cost)
        VALUES (%s, %s, %s, %s)
        """
        params = (router_id, destination_router_id, next_hop_router_id, cost)
        result = self.db.execute_query(query, params)
        if result is not None:
            logger.info(f"Ruta creada: {router_id} -> {destination_router_id} via {next_hop_router_id}")
            return True
        return False
    
    def delete_all(self):
        query = "DELETE FROM route"
        result = self.db.execute_query(query)
        if result is not None:
            logger.info("Todas las rutas eliminadas")
            return True
        return False
    
    def delete_by_router(self, router_id):
        query = "DELETE FROM route WHERE router_id = %s"
        params = (router_id,)
        result = self.db.execute_query(query, params)
        if result is not None:
            logger.info(f"Rutas eliminadas para router {router_id}")
            return True
        return False
    
    def get_by_router(self, router_id):
        query = "SELECT * FROM route WHERE router_id = %s"
        params = (router_id,)
        rows = self.db.fetch_all(query, params)
        routes = []
        for row in rows:
            routes.append({
                'router_id': row['router_id'],
                'destination_router_id': row['destination_router_id'],
                'next_hop_router_id': row['next_hop_router_id'],
                'cost': row['cost']
            })
        return routes
    
    def get_all(self):
        query = "SELECT * FROM route"
        rows = self.db.fetch_all(query)
        routes = []
        for row in rows:
            routes.append({
                'router_id': row['router_id'],
                'destination_router_id': row['destination_router_id'],
                'next_hop_router_id': row['next_hop_router_id'],
                'cost': row['cost']
            })
        return routes
    
    def update_routes(self, router_id, routes_list):
        self.delete_by_router(router_id)
        success = True
        for route in routes_list:
            if not self.create(
                router_id=route['router_id'],
                destination_router_id=route['destination_router_id'],
                next_hop_router_id=route['next_hop_router_id'],
                cost=route['cost']
            ):
                success = False
        return success
    
    def get_next_hop(self, router_id, destination_router_id):
        query = """
        SELECT next_hop_router_id FROM route 
        WHERE router_id = %s AND destination_router_id = %s
        """
        params = (router_id, destination_router_id)
        result = self.db.fetch_one(query, params)
        if result:
            return result['next_hop_router_id']
        return None