"""
Clase Neighbor: representa un vecino del router.
"""

class Neighbor:
    def __init__(self, router_id, ip_address, port, status='active'):
        self.router_id = router_id
        self.ip_address = ip_address
        self.port = port
        self.status = status
        self.last_hello = None
    
    def __repr__(self):
        return f"Neighbor(id={self.router_id}, ip={self.ip_address}, port={self.port}, status={self.status})"
    
    def __eq__(self, other):
        if isinstance(other, Neighbor):
            return self.router_id == other.router_id
        return False
    
    def __hash__(self):
        return hash(self.router_id)
    
    def to_dict(self):
        return {
            'router_id': self.router_id,
            'ip_address': self.ip_address,
            'port': self.port,
            'status': self.status
        }
    
    def is_active(self):
        return self.status == 'active'