"""
SocketClient: cliente TCP que se conecta al Brain Controller.
"""

import socket
import threading
import logging
from .message_handler import MessageHandler

logger = logging.getLogger(__name__)

class SocketClient:
    def __init__(self, router_controller, brain_host, brain_port):
        self.router_controller = router_controller
        self.brain_host = brain_host
        self.brain_port = brain_port
        self.socket = None
        self.connected = False
        self.running = False
        self.message_handler = MessageHandler(router_controller)
    
    def connect(self):
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((self.brain_host, self.brain_port))
            self.connected = True
            self.running = True
            
            logger.info(f"Conectado al Brain Controller en {self.brain_host}:{self.brain_port}")
            
            self.send_router_connected()
            
            receive_thread = threading.Thread(target=self._receive_messages, daemon=True)
            receive_thread.start()
            
            return True
        except Exception as e:
            logger.error(f"Error al conectar con Brain Controller: {e}")
            return False
    
    def send_router_connected(self):
        router_id = self.router_controller.router_id
        config = self.router_controller.config
        
        message = self.message_handler.build_router_connected(
            router_id,
            config['router'].get('port', 0)
        )
        
        self.send_message(message)
        logger.info("ROUTER_CONNECTED enviado al Brain")
    
    def send_create_link(self, link_id, destination_router_id, cost):
        router_id = self.router_controller.router_id
        
        message = self.message_handler.build_create_link(
            link_id,
            router_id,
            destination_router_id,
            cost
        )
        
        self.send_message(message)
        logger.info(f"CREATE_LINK enviado: {link_id}")
    
    def send_delete_link(self, link_id):
        message = self.message_handler.build_delete_link(link_id)
        
        self.send_message(message)
        logger.info(f"DELETE_LINK enviado: {link_id}")
    
    def send_hello(self):
        router_id = self.router_controller.router_id
        
        message = self.message_handler.build_hello(router_id)
        
        self.send_message(message)
        logger.info("HELLO enviado al Brain")
    
    def send_ack_route(self):
        router_id = self.router_controller.router_id
        
        message = self.message_handler.build_ack_route(router_id)
        
        self.send_message(message)
        logger.info("ACK_ROUTE enviado al Brain")
    
    def send_message(self, message):
        if self.connected and self.socket:
            try:
                self.socket.send(message)
                return True
            except Exception as e:
                logger.error(f"Error enviando mensaje: {e}")
                self.connected = False
                return False
        else:
            logger.warning("No hay conexión con el Brain")
            return False
    
    def _receive_messages(self):
        while self.running:
            try:
                data = self.socket.recv(4096)
                if not data:
                    logger.warning("Conexión cerrada por el Brain")
                    self.connected = False
                    break
                
                self.message_handler.handle_message(data)
            
            except Exception as e:
                if self.running:
                    logger.error(f"Error recibiendo mensaje: {e}")
                    self.connected = False
                break
        
        logger.info("Hilo de recepción finalizado")
    
    def disconnect(self):
        logger.info("Desconectando del Brain Controller...")
        self.running = False
        self.connected = False
        
        if self.socket:
            try:
                router_id = self.router_controller.router_id
                message = self.message_handler.build_router_disconnected(router_id)
                self.socket.send(message)
            except:
                pass
            
            self.socket.close()
        
        logger.info("Desconectado del Brain Controller")
    
    def is_connected(self):
        return self.connected