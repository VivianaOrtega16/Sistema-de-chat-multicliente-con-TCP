"""
MessageHandler: procesa mensajes del protocolo usando el paquete protocol.
"""

import logging
import sys
sys.path.append('..')
from protocol.message import build_message, parse_message
from protocol.constants import MessageType

logger = logging.getLogger(__name__)

class MessageHandler:
    def __init__(self, router_controller):
        self.router_controller = router_controller
    
    def handle_message(self, data):
        try:
            message = parse_message(data)
            message_type = message['type']
            payload = message['payload']
            
            logger.info(f"Mensaje recibido del Brain: tipo={hex(message_type)}")
            
            if message_type == MessageType.ACK_CONNECTED:
                self._handle_ack_connected(payload)
            
            elif message_type == MessageType.ROUTE_UPDATE:
                self._handle_route_update(payload)
            
            elif message_type == MessageType.ACK_GENERIC:
                self._handle_ack_generic(payload)
            
            else:
                logger.warning(f"Tipo de mensaje desconocido: {hex(message_type)}")
        
        except Exception as e:
            logger.error(f"Error procesando mensaje: {e}")
    
    def _handle_ack_connected(self, payload):
        router_id = payload.get('router_id')
        status = payload.get('status')
        
        logger.info(f"ACK_CONNECTED recibido: router_id={router_id}, status={status}")
    
    def _handle_route_update(self, payload):
        router_id = payload.get('router_id')
        routes = payload.get('routes', [])
        
        logger.info(f"ROUTE_UPDATE recibido para router {router_id}: {len(routes)} rutas")
        
        self.router_controller.update_routing_table(routes)
        
        from .socket_client import SocketClient
        logger.info("Rutas actualizadas, enviando ACK_ROUTE")
    
    def _handle_ack_generic(self, payload):
        message = payload.get('message', 'unknown')
        logger.info(f"ACK_GENERIC recibido: {message}")
    
    def build_router_connected(self, router_id, port):
        payload = {
            'router_id': router_id,
            'port': port
        }
        return build_message(MessageType.ROUTER_CONNECTED, payload)
    
    def build_router_disconnected(self, router_id):
        payload = {
            'router_id': router_id
        }
        return build_message(MessageType.ROUTER_DISCONNECTED, payload)
    
    def build_create_link(self, link_id, source_router_id, destination_router_id, cost):
        payload = {
            'link_id': link_id,
            'source_router_id': source_router_id,
            'destination_router_id': destination_router_id,
            'cost': cost
        }
        return build_message(MessageType.CREATE_LINK, payload)
    
    def build_delete_link(self, link_id):
        payload = {
            'link_id': link_id
        }
        return build_message(MessageType.DELETE_LINK, payload)
    
    def build_hello(self, router_id):
        payload = {
            'router_id': router_id
        }
        return build_message(MessageType.HELLO, payload)
    
    def build_ack_route(self, router_id):
        payload = {
            'router_id': router_id
        }
        return build_message(MessageType.ACK_ROUTE, payload)