"""
RouterController: controlador principal del router.
"""

import logging
from ..model.routing_table import RoutingTable
from ..model.neighbor import Neighbor
from ..model.dao.database import Database
from ..model.dao.routing_dao import RoutingDAO

logger = logging.getLogger(__name__)

class RouterController:
    def __init__(self, config):
        self.config = config
        self.router_id = config['router']['router_id']
        self.routing_table = RoutingTable(self.router_id)
        self.neighbors = {}
        
        db_config = config['database']
        self.db = Database(
            host=db_config['host'],
            user=db_config['user'],
            password=db_config['password'],
            database=db_config['database']
        )
        
        self.routing_dao = RoutingDAO(self.db)
    
    def initialize(self):
        if not self.db.connect():
            logger.error("No se pudo conectar a la base de datos")
            return False
        
        logger.info(f"RouterController inicializado: {self.router_id}")
        self.load_routes_from_db()
        return True
    
    def load_routes_from_db(self):
        routes = self.routing_dao.get_by_router(self.router_id)
        for route in routes:
            self.routing_table.add_route(
                route['destination_router_id'],
                route['next_hop_router_id'],
                route['cost']
            )
        logger.info(f"Rutas cargadas desde BD: {len(routes)}")
    
    def add_neighbor(self, router_id, ip_address, port):
        neighbor = Neighbor(router_id, ip_address, port, 'active')
        self.neighbors[router_id] = neighbor
        logger.info(f"Vecino agregado: {neighbor}")
    
    def remove_neighbor(self, router_id):
        if router_id in self.neighbors:
            del self.neighbors[router_id]
            logger.info(f"Vecino eliminado: {router_id}")
    
    def get_neighbor(self, router_id):
        return self.neighbors.get(router_id)
    
    def get_all_neighbors(self):
        return list(self.neighbors.values())
    
    def update_routing_table(self, routes_list):
        logger.info(f"Actualizando tabla de enrutamiento con {len(routes_list)} rutas")
        
        self.routing_table.clear_routes()
        
        for route in routes_list:
            self.routing_table.add_route(
                route['destination_router_id'],
                route['next_hop_router_id'],
                route['cost']
            )
        
        self.routing_dao.update_routes(self.router_id, routes_list)
        logger.info("Tabla de enrutamiento actualizada en BD")
    
    def get_routes(self):
        return self.routing_table.to_list()
    
    def get_next_hop(self, destination_router_id):
        route = self.routing_table.get_route(destination_router_id)
        if route:
            return route['next_hop']
        return None
    
    def get_router_info(self):
        return {
            'router_id': self.router_id,
            'neighbors': [n.to_dict() for n in self.neighbors.values()],
            'routes': self.routing_table.to_list()
        }
    
    def shutdown(self):
        logger.info("Cerrando RouterController...")
        self.db.disconnect()