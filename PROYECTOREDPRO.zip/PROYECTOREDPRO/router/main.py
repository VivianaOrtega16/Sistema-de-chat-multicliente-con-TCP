"""
main.py: punto de entrada del Router.
"""

import json
import logging
import sys
import time
from controller.router_controller import RouterController
from controller.socket_client import SocketClient
from view.router_cli import RouterCLI

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def load_config():
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error cargando configuración: {e}")
        sys.exit(1)

def main():
    config = load_config()
    router_id = config['router']['router_id']
    
    logger.info("=" * 60)
    logger.info(f"Iniciando Router {router_id}")
    logger.info("=" * 60)
    
    router_controller = RouterController(config)
    if not router_controller.initialize():
        logger.error("Error inicializando RouterController")
        sys.exit(1)
    
    brain_config = config['brain_controller']
    socket_client = SocketClient(
        router_controller,
        brain_config['host'],
        brain_config['tcp_port']
    )
    
    if not socket_client.connect():
        logger.error("Error conectando con Brain Controller")
        sys.exit(1)
    
    time.sleep(1)
    
    cli = RouterCLI(router_controller, socket_client)
    
    try:
        cli.start()
    except KeyboardInterrupt:
        logger.info("\nInterrupción detectada")
    finally:
        socket_client.disconnect()
        router_controller.shutdown()
        logger.info(f"Router {router_id} detenido")

if __name__ == '__main__':
    main()