"""
RouterCLI: interfaz de línea de comandos para el Router.
"""

import logging

logger = logging.getLogger(__name__)

class RouterCLI:
    def __init__(self, router_controller, socket_client):
        self.router_controller = router_controller
        self.socket_client = socket_client
        self.running = False
    
    def start(self):
        self.running = True
        self.print_banner()
        
        while self.running:
            try:
                command = input(f"\nRouter[{self.router_controller.router_id}]> ").strip().lower()
                self.process_command(command)
            except KeyboardInterrupt:
                print("\n\nInterrupción detectada")
                self.running = False
            except Exception as e:
                logger.error(f"Error procesando comando: {e}")
    
    def print_banner(self):
        router_id = self.router_controller.router_id
        print("=" * 60)
        print(f"           ROUTER {router_id}")
        print("=" * 60)
        print("Comandos disponibles:")
        print("  status        - Ver estado del router")
        print("  routes        - Ver tabla de enrutamiento")
        print("  neighbors     - Ver vecinos")
        print("  hello         - Enviar HELLO al Brain")
        print("  link <id> <dest> <cost> - Crear enlace")
        print("  dellink <id>  - Eliminar enlace")
        print("  help          - Mostrar esta ayuda")
        print("  exit          - Salir")
        print("=" * 60)
    
    def process_command(self, command):
        parts = command.split()
        if not parts:
            return
        
        cmd = parts[0]
        
        if cmd == 'exit' or cmd == 'quit':
            self.running = False
            print("Saliendo...")
        
        elif cmd == 'help':
            self.print_banner()
        
        elif cmd == 'status':
            self.show_status()
        
        elif cmd == 'routes':
            self.show_routes()
        
        elif cmd == 'neighbors':
            self.show_neighbors()
        
        elif cmd == 'hello':
            self.send_hello()
        
        elif cmd == 'link':
            if len(parts) >= 4:
                self.create_link(parts[1], parts[2], int(parts[3]))
            else:
                print("Uso: link <link_id> <destination_router_id> <cost>")
        
        elif cmd == 'dellink':
            if len(parts) >= 2:
                self.delete_link(parts[1])
            else:
                print("Uso: dellink <link_id>")
        
        else:
            print(f"Comando desconocido: {cmd}")
            print("Escribe 'help' para ver comandos disponibles")
    
    def show_status(self):
        info = self.router_controller.get_router_info()
        
        print("\n--- ESTADO DEL ROUTER ---")
        print(f"ID: {info['router_id']}")
        print(f"Conectado al Brain: {'Sí' if self.socket_client.is_connected() else 'No'}")
        print(f"Vecinos: {len(info['neighbors'])}")
        print(f"Rutas: {len(info['routes'])}")
    
    def show_routes(self):
        routes = self.router_controller.get_routes()
        
        print("\n--- TABLA DE ENRUTAMIENTO ---")
        
        if not routes:
            print("No hay rutas disponibles")
            return
        
        print(f"{'Destino':<15} {'Next Hop':<15} {'Costo':<8}")
        print("-" * 40)
        
        for route in routes:
            print(f"{route['destination_router_id']:<15} {route['next_hop_router_id']:<15} {route['cost']:<8}")
    
    def show_neighbors(self):
        neighbors = self.router_controller.get_all_neighbors()
        
        print("\n--- VECINOS ---")
        
        if not neighbors:
            print("No hay vecinos configurados")
            return
        
        print(f"{'ID':<15} {'IP':<15} {'Puerto':<8} {'Estado':<10}")
        print("-" * 50)
        
        for neighbor in neighbors:
            print(f"{neighbor.router_id:<15} {neighbor.ip_address:<15} {neighbor.port:<8} {neighbor.status:<10}")
    
    def send_hello(self):
        if self.socket_client.is_connected():
            self.socket_client.send_hello()
            print("HELLO enviado al Brain Controller")
        else:
            print("No hay conexión con el Brain Controller")
    
    def create_link(self, link_id, destination_router_id, cost):
        if self.socket_client.is_connected():
            self.socket_client.send_create_link(link_id, destination_router_id, cost)
            print(f"CREATE_LINK enviado: {link_id} -> {destination_router_id} (cost={cost})")
        else:
            print("No hay conexión con el Brain Controller")
    
    def delete_link(self, link_id):
        if self.socket_client.is_connected():
            self.socket_client.send_delete_link(link_id)
            print(f"DELETE_LINK enviado: {link_id}")
        else:
            print("No hay conexión con el Brain Controller")