"""
Módulo de vistas para el Router.
Contiene CLI.
"""

from .router_cli import RouterCLI

__all__ = ['RouterCLI']