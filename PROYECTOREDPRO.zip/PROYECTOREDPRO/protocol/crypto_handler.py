"""
Manejador de cifrado y descifrado de payloads.
Actualmente implementación simple, preparada para expandir con RSA/AES.
"""

from .constants import EncryptionMethod

# Estado global para cifrado (puede expandirse con claves RSA/AES)
_encryption_enabled = False
_encryption_method = EncryptionMethod.NONE


def set_encryption(enabled: bool, method: EncryptionMethod = EncryptionMethod.NONE):
    """
    Configura el cifrado global.
    
    Args:
        enabled: Si se debe cifrar
        method: Método de cifrado a usar
    """
    global _encryption_enabled, _encryption_method
    _encryption_enabled = enabled
    _encryption_method = method


def encrypt_payload(payload_bytes: bytes, msg_type: int) -> bytes:
    """
    Cifra un payload.
    
    Actualmente retorna el payload sin modificar (para compatibilidad).
    Preparado para implementar cifrado real con cryptography library.
    
    Args:
        payload_bytes: Bytes del payload a cifrar
        msg_type: Tipo de mensaje (para logging/contexto)
        
    Returns:
        bytes: Payload cifrado (actualmente sin cifrar)
    """
    if not _encryption_enabled or _encryption_method == EncryptionMethod.NONE:
        return payload_bytes
    
    # TODO: Implementar cifrado real según _encryption_method
    # if _encryption_method == EncryptionMethod.AES_128:
    #     ...
    # elif _encryption_method == EncryptionMethod.RSA:
    #     ...
    
    return payload_bytes


def decrypt_payload(encrypted_payload: bytes, msg_type: int) -> bytes:
    """
    Descifra un payload.
    
    Actualmente retorna el payload sin modificar (para compatibilidad).
    Preparado para implementar descifrado real con cryptography library.
    
    Args:
        encrypted_payload: Bytes del payload cifrado
        msg_type: Tipo de mensaje (para logging/contexto)
        
    Returns:
        bytes: Payload descifrado (actualmente sin cambios)
    """
    if not _encryption_enabled or _encryption_method == EncryptionMethod.NONE:
        return encrypted_payload
    
    # TODO: Implementar descifrado real (debe coincidir con encrypt_payload)
    
    return encrypted_payload
