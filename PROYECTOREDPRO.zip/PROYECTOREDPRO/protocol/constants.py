"""
Constantes y enumeraciones para el protocolo de comunicación SDN.
Define tipos de mensajes, flags, métodos de cifrado y otras constantes.
"""
from enum import IntEnum


class MessageType(IntEnum):
    """Tipos de mensajes del protocolo SDN"""
    ROUTER_CONNECTED = 0x01
    ROUTER_DISCONNECTED = 0x02
    CREATE_LINK = 0x03
    DELETE_LINK = 0x04
    HELLO = 0x05
    ACK_CONNECTED = 0x06
    ROUTE_UPDATE = 0x07
    ACK_ROUTE = 0x08
    ACK_GENERIC = 0x10


class MessageFlags(IntEnum):
    """Flags de bits para el header del mensaje"""
    ENCRYPTED = 0x01      # Bit 0: Mensaje cifrado
    REQUIRES_ACK = 0x02   # Bit 1: Requiere ACK
    IS_ACK = 0x04         # Bit 2: Es un ACK
    PRIORITY = 0x08       # Bit 3: Prioridad alta


class TransportProtocol(IntEnum):
    """Protocolos de transporte"""
    TCP = 0x01
    UDP = 0x02


class EncryptionMethod(IntEnum):
    """Métodos de cifrado disponibles"""
    NONE = 0x00
    AES_128 = 0x01
    AES_256 = 0x02
    RSA = 0x03


# Constantes del protocolo
HEADER_SIZE = 6  # bytes
MAX_PAYLOAD_SIZE = 65535  # bytes
PROTOCOL_VERSION = 1


# Configuración por defecto de mensajes
# Mapeo de tipo de mensaje a si requiere cifrado
MESSAGE_ENCRYPTION = {
    MessageType.ROUTER_CONNECTED: False,
    MessageType.ACK_CONNECTED: False,
    MessageType.ROUTER_DISCONNECTED: False,
    MessageType.CREATE_LINK: False,
    MessageType.DELETE_LINK: False,
    MessageType.ROUTE_UPDATE: False,
    MessageType.ACK_ROUTE: False,
    MessageType.HELLO: False,
    MessageType.ACK_GENERIC: False,
}

# Mapeo de tipo de mensaje a si requiere ACK
MESSAGE_REQUIRES_ACK = {
    MessageType.ROUTER_CONNECTED: True,
    MessageType.ACK_CONNECTED: False,
    MessageType.ROUTER_DISCONNECTED: False,
    MessageType.CREATE_LINK: True,
    MessageType.DELETE_LINK: True,
    MessageType.ROUTE_UPDATE: True,
    MessageType.ACK_ROUTE: False,
    MessageType.HELLO: False,
    MessageType.ACK_GENERIC: False,
}
