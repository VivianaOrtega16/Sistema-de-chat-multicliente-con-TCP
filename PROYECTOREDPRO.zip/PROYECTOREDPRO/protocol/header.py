"""
Manejo del header del protocolo SDN.
Header de 6 bytes: TYPE (1) + FLAGS (1) + LENGTH (2) + SEQ (2)
"""
import struct

# Importaciones internas del paquete protocol (siempre relativas)
from .constants import MessageFlags, HEADER_SIZE


class Header:
    """
    Representa el header de un mensaje del protocolo.
    
    Estructura (6 bytes):
    - TYPE (1 byte): Tipo de mensaje
    - FLAGS (1 byte): Flags de control
    - LENGTH (2 bytes): Longitud del payload (big-endian)
    - SEQ (2 bytes): Número de secuencia (big-endian)
    """
    
    def __init__(self, msg_type: int, flags: int, length: int, seq: int):
        """
        Inicializa un header.
        
        Args:
            msg_type: Tipo de mensaje (0-255)
            flags: Byte de flags
            length: Longitud del payload en bytes (0-65535)
            seq: Número de secuencia (0-65535)
        """
        self.msg_type = msg_type & 0xFF
        self.flags = flags & 0xFF
        self.length = length & 0xFFFF
        self.seq = seq & 0xFFFF
    
    def to_bytes(self) -> bytes:
        """
        Convierte el header a bytes.
        
        Returns:
            bytes: 6 bytes con el header serializado
        """
        return struct.pack(
            '!BBHH',  # ! = big-endian, B = unsigned char, H = unsigned short
            self.msg_type,
            self.flags,
            self.length,
            self.seq
        )
    
    @classmethod
    def from_bytes(cls, header_bytes: bytes) -> "Header":
        """
        Crea un Header desde bytes.
        
        Args:
            header_bytes: Exactamente 6 bytes con el header
            
        Returns:
            Header: Instancia de Header
            
        Raises:
            ValueError: Si los bytes no tienen exactamente 6 bytes
        """
        if len(header_bytes) != HEADER_SIZE:
            raise ValueError(f"Header debe tener {HEADER_SIZE} bytes, recibió {len(header_bytes)}")
        
        msg_type, flags, length, seq = struct.unpack('!BBHH', header_bytes)
        return cls(msg_type, flags, length, seq)
    
    def __repr__(self):
        return (f"Header(type=0x{self.msg_type:02X}, flags=0x{self.flags:02X}, "
                f"length={self.length}, seq={self.seq})")


def build_flags(encrypted=False, requires_ack=False, is_ack=False, priority=False) -> int:
    """
    Construye el byte de flags a partir de opciones booleanas.
    
    Args:
        encrypted: Si el mensaje está cifrado
        requires_ack: Si requiere ACK
        is_ack: Si es un mensaje ACK
        priority: Si tiene prioridad alta
        
    Returns:
        int: Byte de flags (0-255)
    """
    flags = 0
    if encrypted:
        flags |= MessageFlags.ENCRYPTED
    if requires_ack:
        flags |= MessageFlags.REQUIRES_ACK
    if is_ack:
        flags |= MessageFlags.IS_ACK
    if priority:
        flags |= MessageFlags.PRIORITY
    return flags


def parse_flags(flags: int) -> dict:
    """
    Parsea el byte de flags a un diccionario de opciones.
    
    Args:
        flags: Byte de flags (0-255)
        
    Returns:
        dict: Diccionario con los flags parseados
    """
    return {
        'encrypted': bool(flags & MessageFlags.ENCRYPTED),
        'requires_ack': bool(flags & MessageFlags.REQUIRES_ACK),
        'is_ack': bool(flags & MessageFlags.IS_ACK),
        'priority': bool(flags & MessageFlags.PRIORITY),
    }
