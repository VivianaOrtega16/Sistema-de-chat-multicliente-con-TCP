"""
protocol package
================
Paquete del protocolo SDN:
- Header de 6 bytes
- Builder y parser de mensajes
- Tipos de mensajes, flags y configuración
- Criptografía RSA/AES

Este archivo expone las funciones y clases principales
para facilitar su importación desde otras partes del proyecto.
"""

# Importación de tipos y constantes del protocolo
from .message_types import (
    MessageType,
    MessageFlags,
    TransportProtocol,
    EncryptionMethod,
    RouterStatus,
    LinkStatus,
    PROTOCOL_VERSION,
    HEADER_SIZE,
    MAX_PAYLOAD_SIZE,
    MESSAGE_TRANSPORT,
    MESSAGE_ENCRYPTION,
    MESSAGE_REQUIRES_ACK,
    ErrorCode
)

# Importación de Header y funciones auxiliares
from .header import (
    Header,
    build_flags,
    parse_flags
)

# Importación del builder (construcción de mensajes)
from .message_builder import (
    build_message,
    build_ack_message,
    reset_sequence_counter
)

# Importación del parser (lectura de mensajes)
from .message_parser import (
    parse_message,
    parse_header_only,
    validate_message_structure,
    ParsedMessage
)

# Importación de criptografía
from .crypto_handler import (
    encrypt_payload,
    decrypt_payload,
    generate_rsa_keys,
    get_own_public_key_pem,
    load_remote_public_key,
    generate_aes_key,
    set_aes_session_key,
    set_current_entity
)

__all__ = [
    # Tipos y constantes
    "MessageType",
    "MessageFlags",
    "TransportProtocol",
    "EncryptionMethod",
    "RouterStatus",
    "LinkStatus",
    "PROTOCOL_VERSION",
    "HEADER_SIZE",
    "MAX_PAYLOAD_SIZE",
    "MESSAGE_TRANSPORT",
    "MESSAGE_ENCRYPTION",
    "MESSAGE_REQUIRES_ACK",
    "ErrorCode",

    # Header
    "Header",
    "build_flags",
    "parse_flags",

    # Builder
    "build_message",
    "build_ack_message",
    "reset_sequence_counter",

    # Parser
    "parse_message",
    "parse_header_only",
    "validate_message_structure",
    "ParsedMessage",

    # Crypto
    "encrypt_payload",
    "decrypt_payload",
    "generate_rsa_keys",
    "get_own_public_key_pem",
    "load_remote_public_key",
    "generate_aes_key",
    "set_aes_session_key",
    "set_current_entity",
]
