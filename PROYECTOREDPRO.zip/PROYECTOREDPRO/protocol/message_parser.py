"""
Parser de mensajes del protocolo SDN.
Maneja la deserialización de bytes a mensajes.
"""
import json

# Importaciones internas del paquete protocol (siempre relativas)
from .header import Header, parse_flags
from .constants import HEADER_SIZE, MessageType
from .crypto_handler import decrypt_payload


def parse_message(raw_bytes: bytes) -> dict:
    """
    Parsea un mensaje completo del protocolo.
    
    Args:
        raw_bytes: Bytes del mensaje completo (header + payload)
        
    Returns:
        dict: Diccionario con estructura:
            {
                'type': MessageType o int,
                'payload': dict o None
            }
            
    Raises:
        ValueError: Si el mensaje está mal formado
        
    Example:
        >>> message = parse_message(raw_bytes)
        >>> message_type = message['type']
        >>> payload = message['payload']
    """
    # Verificar longitud mínima
    if len(raw_bytes) < HEADER_SIZE:
        raise ValueError(f"Mensaje muy corto: {len(raw_bytes)} bytes, mínimo {HEADER_SIZE}")
    
    # Separar header y payload
    header_bytes = raw_bytes[:HEADER_SIZE]
    payload_bytes = raw_bytes[HEADER_SIZE:]
    
    # Parsear header
    header = Header.from_bytes(header_bytes)
    
    # Verificar que el payload tenga la longitud correcta
    if len(payload_bytes) != header.length:
        raise ValueError(
            f"Longitud de payload incorrecta: esperado {header.length}, "
            f"recibido {len(payload_bytes)}"
        )
    
    # Parsear flags
    flags = parse_flags(header.flags)
    
    # Descifrar payload si está cifrado
    if flags['encrypted'] and len(payload_bytes) > 0:
        payload_bytes = decrypt_payload(payload_bytes, header.msg_type)
    
    # Decodificar payload JSON
    payload = None
    if header.length > 0:
        try:
            payload_str = payload_bytes.decode('utf-8')
            payload = json.loads(payload_str)
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            raise ValueError(f"Error decodificando payload: {e}")
    
    # Retornar estructura esperada por Brain y Router
    return {
        'type': header.msg_type,  # Puede ser comparado con MessageType
        'payload': payload
    }


def parse_header_only(raw_bytes: bytes) -> Header:
    """
    Parsea solo el header de un mensaje.
    
    Útil para inspección rápida sin procesar el payload completo.
    
    Args:
        raw_bytes: Al menos los primeros 6 bytes del mensaje
        
    Returns:
        Header: Header parseado
        
    Raises:
        ValueError: Si no hay suficientes bytes
    """
    if len(raw_bytes) < HEADER_SIZE:
        raise ValueError(f"Necesita al menos {HEADER_SIZE} bytes")
    
    return Header.from_bytes(raw_bytes[:HEADER_SIZE])


def validate_message_structure(raw_bytes: bytes) -> tuple[bool, str]:
    """
    Valida la estructura de un mensaje sin parsearlo completamente.
    
    Args:
        raw_bytes: Bytes del mensaje a validar
        
    Returns:
        tuple: (es_válido, mensaje_error)
               Si es_válido=True, mensaje_error=""
               Si es_válido=False, mensaje_error contiene la descripción del error
    """
    # Verificar longitud mínima
    if len(raw_bytes) < HEADER_SIZE:
        return False, f"Mensaje muy corto: {len(raw_bytes)} bytes"
    
    try:
        # Parsear header
        header = Header.from_bytes(raw_bytes[:HEADER_SIZE])
        
        # Verificar que hay suficientes bytes para el payload
        expected_total = HEADER_SIZE + header.length
        if len(raw_bytes) != expected_total:
            return False, f"Longitud incorrecta: esperado {expected_total}, recibido {len(raw_bytes)}"
        
        # Verificar que el tipo de mensaje es válido
        try:
            MessageType(header.msg_type)
        except ValueError:
            return False, f"Tipo de mensaje desconocido: 0x{header.msg_type:02X}"
        
        return True, ""
        
    except Exception as e:
        return False, f"Error de validación: {str(e)}"
