"""
Módulo principal del paquete protocol.
Proporciona la interfaz pública para construir y parsear mensajes.

Este módulo es usado por brain_controller y router para todas las
operaciones con mensajes del protocolo.
"""

# Importar desde los módulos internos del paquete (imports relativos)
from .message_builder import (
    build_message,
    build_ack_message,
    reset_sequence_counter,
)
from .message_parser import (
    parse_message,
    parse_header_only,
    validate_message_structure,
)

__all__ = [
    # Construcción de mensajes
    "build_message",
    "build_ack_message",
    "reset_sequence_counter",

    # Parseo de mensajes
    "parse_message",
    "parse_header_only",
    "validate_message_structure",
]
