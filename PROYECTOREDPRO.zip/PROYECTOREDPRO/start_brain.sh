#!/bin/bash

# Script para iniciar el Brain Controller

echo "=========================================="
echo "  Iniciando Brain Controller"
echo "=========================================="
echo ""

# Verificar que estamos en el directorio correcto
if [ ! -d "brain_controller" ]; then
    echo "Error: Directorio brain_controller no encontrado"
    echo "Ejecuta este script desde el directorio raíz del proyecto"
    exit 1
fi

# Verificar que existe el archivo de configuración
if [ ! -f "brain_controller/config.json" ]; then
    echo "Error: brain_controller/config.json no encontrado"
    echo "Crea el archivo de configuración primero"
    exit 1
fi

# Verificar que existe main.py
if [ ! -f "brain_controller/main.py" ]; then
    echo "Error: brain_controller/main.py no encontrado"
    exit 1
fi

# Cambiar al directorio del brain controller
cd brain_controller

# Verificar conexión a la base de datos
echo "Verificando conexión a la base de datos..."
python3 -c "
import json
import mysql.connector
try:
    with open('config.json') as f:
        config = json.load(f)
    db_config = config['database']
    conn = mysql.connector.connect(
        host=db_config['host'],
        user=db_config['user'],
        password=db_config['password'],
        database=db_config['database']
    )
    conn.close()
    print('✓ Conexión a la base de datos exitosa')
except Exception as e:
    print(f'✗ Error de conexión: {e}')
    exit(1)
" || exit 1

echo ""
echo "Iniciando Brain Controller..."
echo ""

# Ejecutar el Brain Controller
python3 main.py