"""
CLI: interfaz de línea de comandos para el BrainController.
"""

import logging

logger = logging.getLogger(__name__)

class CLI:
    def __init__(self, brain_controller):
        self.brain_controller = brain_controller
        self.running = False
    
    def start(self):
        self.running = True
        self.print_banner()
        
        while self.running:
            try:
                command = input("\nBrain> ").strip().lower()
                self.process_command(command)
            except KeyboardInterrupt:
                print("\n\nInterrupción detectada")
                self.running = False
            except Exception as e:
                logger.error(f"Error procesando comando: {e}")
    
    def print_banner(self):
        print("=" * 60)
        print("           BRAIN CONTROLLER - SDN")
        print("=" * 60)
        print("Comandos disponibles:")
        print("  status        - Ver estado de la topología")
        print("  routers       - Listar routers")
        print("  links         - Listar enlaces")
        print("  routes <id>   - Ver rutas de un router")
        print("  recalculate   - Recalcular todas las rutas")
        print("  help          - Mostrar esta ayuda")
        print("  exit          - Salir")
        print("=" * 60)
    
    def process_command(self, command):
        parts = command.split()
        if not parts:
            return
        
        cmd = parts[0]
        
        if cmd == 'exit' or cmd == 'quit':
            self.running = False
            print("Saliendo...")
        
        elif cmd == 'help':
            self.print_banner()
        
        elif cmd == 'status':
            self.show_status()
        
        elif cmd == 'routers':
            self.show_routers()
        
        elif cmd == 'links':
            self.show_links()
        
        elif cmd == 'routes':
            if len(parts) > 1:
                self.show_routes(parts[1])
            else:
                print("Uso: routes <router_id>")
        
        elif cmd == 'recalculate':
            self.recalculate_routes()
        
        else:
            print(f"Comando desconocido: {cmd}")
            print("Escribe 'help' para ver comandos disponibles")
    
    def show_status(self):
        topology_info = self.brain_controller.get_topology_info()
        routers = topology_info['routers']
        links = topology_info['links']
        
        print("\n--- ESTADO DE LA TOPOLOGÍA ---")
        print(f"Routers totales: {len(routers)}")
        print(f"Enlaces totales: {len(links)}")
        
        connected = sum(1 for r in routers if r['status'] == 'connected')
        active_links = sum(1 for l in links if l['status'] == 'active')
        
        print(f"Routers conectados: {connected}")
        print(f"Enlaces activos: {active_links}")
    
    def show_routers(self):
        topology_info = self.brain_controller.get_topology_info()
        routers = topology_info['routers']
        
        print("\n--- ROUTERS ---")
        print(f"{'ID':<15} {'IP':<15} {'Puerto':<8} {'Estado':<12}")
        print("-" * 60)
        
        for router in routers:
            print(f"{router['router_id']:<15} {router['ip_address']:<15} {router['port']:<8} {router['status']:<12}")
    
    def show_links(self):
        topology_info = self.brain_controller.get_topology_info()
        links = topology_info['links']
        
        print("\n--- ENLACES ---")
        print(f"{'ID':<15} {'Origen':<15} {'Destino':<15} {'Costo':<8} {'Estado':<10}")
        print("-" * 70)
        
        for link in links:
            print(f"{link['link_id']:<15} {link['source_router_id']:<15} {link['destination_router_id']:<15} {link['cost']:<8} {link['status']:<10}")
    
    def show_routes(self, router_id):
        routes = self.brain_controller.get_routes_for_router(router_id)
        
        print(f"\n--- RUTAS PARA ROUTER {router_id} ---")
        
        if not routes:
            print("No hay rutas disponibles")
            return
        
        print(f"{'Destino':<15} {'Next Hop':<15} {'Costo':<8}")
        print("-" * 40)
        
        for route in routes:
            print(f"{route['destination_router_id']:<15} {route['next_hop_router_id']:<15} {route['cost']:<8}")
    
    def recalculate_routes(self):
        print("Recalculando rutas...")
        self.brain_controller.recalculate_routes()
        print("Rutas recalculadas exitosamente")