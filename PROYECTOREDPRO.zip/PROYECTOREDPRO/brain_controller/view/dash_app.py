"""
DashApp: aplicación web con Dash para visualizar la topología.
"""

import logging
from dash import Dash, html, dcc
from dash.dependencies import Input, Output
import plotly.graph_objs as go

logger = logging.getLogger(__name__)

class DashApp:
    def __init__(self, brain_controller, host='0.0.0.0', port=8050):
        self.brain_controller = brain_controller
        self.host = host
        self.port = port
        self.app = Dash(__name__)
        self.setup_layout()
        self.setup_callbacks()
    
    def setup_layout(self):
        self.app.layout = html.Div([
            html.H1("Brain Controller - Topología SDN", style={'textAlign': 'center'}),
            
            dcc.Interval(
                id='interval-component',
                interval=3000,
                n_intervals=0
            ),
            
            html.Div([
                html.Div([
                    html.H3("Estado General"),
                    html.Div(id='status-info')
                ], style={'width': '48%', 'display': 'inline-block', 'verticalAlign': 'top'}),
                
                html.Div([
                    html.H3("Gráfico de Red"),
                    dcc.Graph(id='network-graph')
                ], style={'width': '48%', 'display': 'inline-block', 'verticalAlign': 'top'})
            ]),
            
            html.Div([
                html.H3("Routers"),
                html.Div(id='routers-table')
            ]),
            
            html.Div([
                html.H3("Enlaces"),
                html.Div(id='links-table')
            ])
        ])
    
    def setup_callbacks(self):
        @self.app.callback(
            [Output('status-info', 'children'),
             Output('network-graph', 'figure'),
             Output('routers-table', 'children'),
             Output('links-table', 'children')],
            [Input('interval-component', 'n_intervals')]
        )
        def update_dashboard(n):
            topology_info = self.brain_controller.get_topology_info()
            routers = topology_info['routers']
            links = topology_info['links']
            
            status_div = self.create_status_info(routers, links)
            network_fig = self.create_network_graph(routers, links)
            routers_table = self.create_routers_table(routers)
            links_table = self.create_links_table(links)
            
            return status_div, network_fig, routers_table, links_table
    
    def create_status_info(self, routers, links):
        connected = sum(1 for r in routers if r['status'] == 'connected')
        active_links = sum(1 for l in links if l['status'] == 'active')
        
        return html.Div([
            html.P(f"Routers totales: {len(routers)}"),
            html.P(f"Routers conectados: {connected}"),
            html.P(f"Enlaces totales: {len(links)}"),
            html.P(f"Enlaces activos: {active_links}")
        ])
    
    def create_network_graph(self, routers, links):
        edge_trace = []
        
        for link in links:
            if link['status'] == 'active':
                edge_trace.append(go.Scatter(
                    x=[0, 1],
                    y=[0, 1],
                    mode='lines',
                    line=dict(width=2, color='blue'),
                    hoverinfo='none'
                ))
        
        node_trace = go.Scatter(
            x=[i for i in range(len(routers))],
            y=[0 for _ in routers],
            mode='markers+text',
            text=[r['router_id'] for r in routers],
            textposition='top center',
            marker=dict(
                size=20,
                color=['green' if r['status'] == 'connected' else 'red' for r in routers]
            )
        )
        
        fig = go.Figure(data=[node_trace])
        fig.update_layout(
            showlegend=False,
            hovermode='closest',
            margin=dict(b=0, l=0, r=0, t=0),
            xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)
        )
        
        return fig
    
    def create_routers_table(self, routers):
        if not routers:
            return html.P("No hay routers")
        
        header = html.Tr([
            html.Th("ID"),
            html.Th("IP"),
            html.Th("Puerto"),
            html.Th("Estado")
        ])
        
        rows = [html.Tr([
            html.Td(r['router_id']),
            html.Td(r['ip_address']),
            html.Td(r['port']),
            html.Td(r['status'])
        ]) for r in routers]
        
        return html.Table([html.Thead(header), html.Tbody(rows)], style={'width': '100%', 'border': '1px solid black'})
    
    def create_links_table(self, links):
        if not links:
            return html.P("No hay enlaces")
        
        header = html.Tr([
            html.Th("ID"),
            html.Th("Origen"),
            html.Th("Destino"),
            html.Th("Costo"),
            html.Th("Estado")
        ])
        
        rows = [html.Tr([
            html.Td(l['link_id']),
            html.Td(l['source_router_id']),
            html.Td(l['destination_router_id']),
            html.Td(l['cost']),
            html.Td(l['status'])
        ]) for l in links]
        
        return html.Table([html.Thead(header), html.Tbody(rows)], style={'width': '100%', 'border': '1px solid black'})
    
    def run(self):
        logger.info(f"Iniciando Dash app en {self.host}:{self.port}")
        self.app.run_server(host=self.host, port=self.port, debug=False)