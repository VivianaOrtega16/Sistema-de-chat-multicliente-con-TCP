"""
Módulo de vistas para el BrainController.
Contiene CLI y aplicación Dash.
"""

from .cli import CLI
from .dash_app import DashApp

__all__ = ['CLI', 'DashApp']