"""
main.py: punto de entrada del BrainController.
"""

import json
import logging
import threading
import sys
from controller.brain_controller import BrainController
from controller.socket_server import SocketServer
from view.cli import CLI
from view.dash_app import DashApp

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def load_config():
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error cargando configuración: {e}")
        sys.exit(1)

def main():
    logger.info("=" * 60)
    logger.info("Iniciando Brain Controller")
    logger.info("=" * 60)
    
    config = load_config()
    
    brain = BrainController(config)
    if not brain.initialize():
        logger.error("Error inicializando BrainController")
        sys.exit(1)
    
    server_config = config['server']
    socket_server = SocketServer(
        brain,
        server_config['host'],
        server_config['tcp_port']
    )
    
    if not socket_server.start():
        logger.error("Error iniciando servidor TCP")
        sys.exit(1)
    
    if config.get('enable_dash', False):
        dash_config = config.get('dash', {})
        dash_app = DashApp(
            brain,
            dash_config.get('host', '0.0.0.0'),
            dash_config.get('port', 8050)
        )
        dash_thread = threading.Thread(target=dash_app.run, daemon=True)
        dash_thread.start()
        logger.info("Dash app iniciado en segundo plano")
    
    cli = CLI(brain)
    
    try:
        cli.start()
    except KeyboardInterrupt:
        logger.info("\nInterrupción detectada")
    finally:
        socket_server.stop()
        brain.shutdown()
        logger.info("Brain Controller detenido")

if __name__ == '__main__':
    main()