"""
Constructor de mensajes del protocolo SDN.
Maneja la serialización de mensajes a bytes.
"""
import json

# Importaciones internas del paquete protocol (SIEMPRE relativas)
from .header import Header, build_flags
from .constants import MessageType, MESSAGE_ENCRYPTION, MESSAGE_REQUIRES_ACK
from .crypto_handler import encrypt_payload

# Contador de secuencia global (0-65535 con wrap-around)
_sequence_counter = 0


def _get_next_sequence() -> int:
    """Obtiene el siguiente número de secuencia."""
    global _sequence_counter
    seq = _sequence_counter
    _sequence_counter = (_sequence_counter + 1) % 65536
    return seq


def reset_sequence_counter():
    """Reinicia el contador de secuencia a 0."""
    global _sequence_counter
    _sequence_counter = 0


def build_message(msg_type, payload_dict=None, encrypted=None, seq=None) -> bytes:
    """
    Construye un mensaje completo del protocolo.
    
    Args:
        msg_type: Tipo de mensaje (MessageType o int)
        payload_dict: Diccionario con datos del payload (opcional)
        encrypted: Forzar cifrado True/False, o None para usar configuración por defecto
        seq: Número de secuencia manual, o None para usar contador automático
        
    Returns:
        bytes: Mensaje completo (header + payload)
        
    Example:
        >>> msg = build_message(MessageType.ROUTER_CONNECTED, {'router_id': 'R1', 'port': 5000})
    """
    # Convertir msg_type a int si es enum
    msg_type_int = int(msg_type)
    
    # Serializar payload a JSON si existe
    if payload_dict is not None:
        payload_json = json.dumps(payload_dict, separators=(',', ':'))
        payload_bytes = payload_json.encode('utf-8')
    else:
        payload_bytes = b''
    
    # Determinar si se debe cifrar
    if encrypted is None:
        should_encrypt = MESSAGE_ENCRYPTION.get(msg_type_int, False)
    else:
        should_encrypt = encrypted
    
    # Cifrar payload si es necesario
    if should_encrypt and len(payload_bytes) > 0:
        payload_bytes = encrypt_payload(payload_bytes, msg_type_int)
    
    # Determinar si requiere ACK
    requires_ack = MESSAGE_REQUIRES_ACK.get(msg_type_int, False)
    
    # Construir flags
    flags = build_flags(
        encrypted=should_encrypt,
        requires_ack=requires_ack,
        is_ack=False,
        priority=False
    )
    
    # Obtener número de secuencia
    if seq is None:
        seq = _get_next_sequence()
    
    # Crear header
    header = Header(
        msg_type=msg_type_int,
        flags=flags,
        length=len(payload_bytes),
        seq=seq
    )
    
    # Ensamblar mensaje completo
    return header.to_bytes() + payload_bytes


def build_ack_message(original_seq, ack_type=MessageType.ACK_GENERIC, payload_dict=None) -> bytes:
    """
    Construye un mensaje de ACK.
    
    Args:
        original_seq: Número de secuencia del mensaje original
        ack_type: Tipo de ACK (por defecto ACK_GENERIC)
        payload_dict: Payload opcional para el ACK
        
    Returns:
        bytes: Mensaje ACK completo
        
    Example:
        >>> ack = build_ack_message(original_seq=123, ack_type=MessageType.ACK_CONNECTED)
    """
    # Convertir ack_type a int
    ack_type_int = int(ack_type)
    
    # Serializar payload si existe
    if payload_dict is not None:
        payload_json = json.dumps(payload_dict, separators=(',', ':'))
        payload_bytes = payload_json.encode('utf-8')
    else:
        payload_bytes = b''
    
    # Los ACKs no requieren cifrado ni ACK adicional
    flags = build_flags(
        encrypted=False,
        requires_ack=False,
        is_ack=True,
        priority=False
    )
    
    # Crear header con el número de secuencia del mensaje original
    header = Header(
        msg_type=ack_type_int,
        flags=flags,
        length=len(payload_bytes),
        seq=original_seq
    )
    
    return header.to_bytes() + payload_bytes
