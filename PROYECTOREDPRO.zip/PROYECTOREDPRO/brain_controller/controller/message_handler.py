"""
MessageHandler: procesa mensajes del protocolo usando el paquete protocol.
"""

import logging
import sys
sys.path.append('..')
from protocol.message import build_message, parse_message
from protocol.constants import MessageType

logger = logging.getLogger(__name__)

class MessageHandler:
    def __init__(self, brain_controller):
        self.brain_controller = brain_controller
    
    def handle_message(self, data, client_address):
        try:
            message = parse_message(data)
            message_type = message['type']
            payload = message['payload']
            
            logger.info(f"Mensaje recibido de {client_address}: tipo={hex(message_type)}")
            
            if message_type == MessageType.ROUTER_CONNECTED:
                return self._handle_router_connected(payload, client_address)
            
            elif message_type == MessageType.ROUTER_DISCONNECTED:
                return self._handle_router_disconnected(payload)
            
            elif message_type == MessageType.CREATE_LINK:
                return self._handle_create_link(payload)
            
            elif message_type == MessageType.DELETE_LINK:
                return self._handle_delete_link(payload)
            
            elif message_type == MessageType.HELLO:
                return self._handle_hello(payload)
            
            elif message_type == MessageType.ACK_ROUTE:
                return self._handle_ack_route(payload)
            
            else:
                logger.warning(f"Tipo de mensaje desconocido: {hex(message_type)}")
                return None, None
        
        except Exception as e:
            logger.error(f"Error procesando mensaje: {e}")
            return None, None
    
    def _handle_router_connected(self, payload, client_address):
        router_id = payload.get('router_id')
        ip_address = client_address[0]
        port = payload.get('port', 0)
        
        self.brain_controller.handle_router_connected(router_id, ip_address, port)
        
        response = build_message(MessageType.ACK_CONNECTED, {
            'router_id': router_id,
            'status': 'connected'
        })
        
        return response, router_id
    
    def _handle_router_disconnected(self, payload):
        router_id = payload.get('router_id')
        
        self.brain_controller.handle_router_disconnected(router_id)
        
        response = build_message(MessageType.ACK_GENERIC, {
            'message': 'disconnected'
        })
        
        return response, router_id
    
    def _handle_create_link(self, payload):
        link_id = payload.get('link_id')
        source_router_id = payload.get('source_router_id')
        destination_router_id = payload.get('destination_router_id')
        cost = payload.get('cost', 1)
        
        self.brain_controller.handle_create_link(link_id, source_router_id, destination_router_id, cost)
        
        response = build_message(MessageType.ACK_GENERIC, {
            'message': 'link_created'
        })
        
        return response, source_router_id
    
    def _handle_delete_link(self, payload):
        link_id = payload.get('link_id')
        
        self.brain_controller.handle_delete_link(link_id)
        
        response = build_message(MessageType.ACK_GENERIC, {
            'message': 'link_deleted'
        })
        
        return response, None
    
    def _handle_hello(self, payload):
        router_id = payload.get('router_id')
        logger.info(f"HELLO recibido de router {router_id}")
        
        response = build_message(MessageType.ACK_GENERIC, {
            'message': 'hello_received'
        })
        
        return response, router_id
    
    def _handle_ack_route(self, payload):
        router_id = payload.get('router_id')
        logger.info(f"ACK_ROUTE recibido de router {router_id}")
        
        return None, router_id
    
    def build_route_update(self, router_id, routes):
        payload = {
            'router_id': router_id,
            'routes': routes
        }
        
        message = build_message(MessageType.ROUTE_UPDATE, payload)
        logger.info(f"ROUTE_UPDATE construido para router {router_id} con {len(routes)} rutas")
        
        return message