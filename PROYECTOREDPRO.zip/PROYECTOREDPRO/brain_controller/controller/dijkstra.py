"""
Dijkstra: implementación del algoritmo de Dijkstra para calcular rutas óptimas.
"""

import heapq
import logging
from ..model.routing_table import RoutingTable

logger = logging.getLogger(__name__)

class Dijkstra:
    def calculate_routes(self, graph, source_router_id):
        if source_router_id not in graph:
            logger.warning(f"Router {source_router_id} no encontrado en el grafo")
            return RoutingTable(source_router_id)
        
        distances = {node: float('infinity') for node in graph}
        distances[source_router_id] = 0
        
        previous_nodes = {node: None for node in graph}
        
        priority_queue = [(0, source_router_id)]
        visited = set()
        
        while priority_queue:
            current_distance, current_node = heapq.heappop(priority_queue)
            
            if current_node in visited:
                continue
            
            visited.add(current_node)
            
            if current_distance > distances[current_node]:
                continue
            
            for neighbor, weight in graph[current_node].items():
                distance = current_distance + weight
                
                if distance < distances[neighbor]:
                    distances[neighbor] = distance
                    previous_nodes[neighbor] = current_node
                    heapq.heappush(priority_queue, (distance, neighbor))
        
        routing_table = RoutingTable(source_router_id)
        
        for destination in graph:
            if destination == source_router_id:
                continue
            
            if distances[destination] == float('infinity'):
                continue
            
            next_hop = self._get_next_hop(source_router_id, destination, previous_nodes)
            
            if next_hop:
                routing_table.add_route(destination, next_hop, distances[destination])
        
        logger.info(f"Dijkstra calculado para router {source_router_id}: {len(routing_table.routes)} rutas")
        return routing_table
    
    def _get_next_hop(self, source, destination, previous_nodes):
        path = []
        current = destination
        
        while current is not None:
            path.append(current)
            current = previous_nodes[current]
        
        path.reverse()
        
        if len(path) < 2 or path[0] != source:
            return None
        
        return path[1]