"""
SocketServer: servidor TCP que escucha conexiones de routers.
"""

import socket
import threading
import logging
from .message_handler import MessageHandler

logger = logging.getLogger(__name__)

class SocketServer:
    def __init__(self, brain_controller, host, port):
        self.brain_controller = brain_controller
        self.host = host
        self.port = port
        self.server_socket = None
        self.running = False
        self.clients = {}
        self.message_handler = MessageHandler(brain_controller)
    
    def start(self):
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(5)
            self.running = True
            
            logger.info(f"Servidor TCP iniciado en {self.host}:{self.port}")
            
            accept_thread = threading.Thread(target=self._accept_connections, daemon=True)
            accept_thread.start()
            
            return True
        except Exception as e:
            logger.error(f"Error al iniciar servidor: {e}")
            return False
    
    def _accept_connections(self):
        while self.running:
            try:
                client_socket, client_address = self.server_socket.accept()
                logger.info(f"Nueva conexión desde {client_address}")
                
                client_thread = threading.Thread(
                    target=self._handle_client,
                    args=(client_socket, client_address),
                    daemon=True
                )
                client_thread.start()
            except Exception as e:
                if self.running:
                    logger.error(f"Error al aceptar conexión: {e}")
    
    def _handle_client(self, client_socket, client_address):
        router_id = None
        
        try:
            while self.running:
                data = client_socket.recv(4096)
                if not data:
                    break
                
                response, router_id = self.message_handler.handle_message(data, client_address)
                
                if router_id and router_id not in self.clients:
                    self.clients[router_id] = {
                        'socket': client_socket,
                        'address': client_address
                    }
                
                if response:
                    client_socket.send(response)
        
        except Exception as e:
            logger.error(f"Error manejando cliente {client_address}: {e}")
        
        finally:
            if router_id and router_id in self.clients:
                del self.clients[router_id]
                self.brain_controller.handle_router_disconnected(router_id)
            
            client_socket.close()
            logger.info(f"Conexión cerrada: {client_address}")
    
    def send_to_router(self, router_id, message):
        if router_id in self.clients:
            try:
                client_socket = self.clients[router_id]['socket']
                client_socket.send(message)
                logger.info(f"Mensaje enviado a router {router_id}")
                return True
            except Exception as e:
                logger.error(f"Error enviando mensaje a router {router_id}: {e}")
                return False
        else:
            logger.warning(f"Router {router_id} no conectado")
            return False
    
    def broadcast_route_updates(self):
        for router_id in list(self.clients.keys()):
            routes = self.brain_controller.get_routes_for_router(router_id)
            if routes:
                message = self.message_handler.build_route_update(router_id, routes)
                self.send_to_router(router_id, message)
    
    def stop(self):
        logger.info("Deteniendo servidor TCP...")
        self.running = False
        
        for router_id in list(self.clients.keys()):
            try:
                self.clients[router_id]['socket'].close()
            except:
                pass
        
        if self.server_socket:
            self.server_socket.close()
        
        logger.info("Servidor TCP detenido")