"""
Clase RoutingTable: representa las rutas calculadas para cada router.
"""

class RoutingTable:
    def __init__(self, router_id):
        self.router_id = router_id
        self.routes = {}
    
    def add_route(self, destination_router_id, next_hop_router_id, cost):
        self.routes[destination_router_id] = {
            'next_hop': next_hop_router_id,
            'cost': cost
        }
    
    def get_route(self, destination_router_id):
        return self.routes.get(destination_router_id)
    
    def get_all_routes(self):
        return self.routes
    
    def clear_routes(self):
        self.routes.clear()
    
    def to_list(self):
        route_list = []
        for dest_id, route_info in self.routes.items():
            route_list.append({
                'router_id': self.router_id,
                'destination_router_id': dest_id,
                'next_hop_router_id': route_info['next_hop'],
                'cost': route_info['cost']
            })
        return route_list
    
    def __repr__(self):
        return f"RoutingTable(router_id={self.router_id}, routes={len(self.routes)})"