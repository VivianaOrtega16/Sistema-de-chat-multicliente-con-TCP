"""
Clase Topology: representa la topología completa de la red SDN.
Mantiene routers, links y tablas de enrutamiento.
"""

from .router import Router
from .link import Link
from .routing_table import RoutingTable

class Topology:
    def __init__(self):
        self.routers = {}
        self.links = {}
        self.routing_tables = {}
    
    def add_router(self, router):
        if isinstance(router, Router):
            self.routers[router.router_id] = router
            if router.router_id not in self.routing_tables:
                self.routing_tables[router.router_id] = RoutingTable(router.router_id)
    
    def remove_router(self, router_id):
        if router_id in self.routers:
            del self.routers[router_id]
        if router_id in self.routing_tables:
            del self.routing_tables[router_id]
    
    def get_router(self, router_id):
        return self.routers.get(router_id)
    
    def get_all_routers(self):
        return list(self.routers.values())
    
    def add_link(self, link):
        if isinstance(link, Link):
            self.links[link.link_id] = link
            source = self.get_router(link.source_router_id)
            destination = self.get_router(link.destination_router_id)
            if source:
                source.add_neighbor(link.destination_router_id)
            if destination:
                destination.add_neighbor(link.source_router_id)
    
    def remove_link(self, link_id):
        if link_id in self.links:
            link = self.links[link_id]
            source = self.get_router(link.source_router_id)
            destination = self.get_router(link.destination_router_id)
            if source:
                source.remove_neighbor(link.destination_router_id)
            if destination:
                destination.remove_neighbor(link.source_router_id)
            del self.links[link_id]
    
    def get_link(self, link_id):
        return self.links.get(link_id)
    
    def get_all_links(self):
        return list(self.links.values())
    
    def get_active_links(self):
        return [link for link in self.links.values() if link.is_active()]
    
    def get_routing_table(self, router_id):
        return self.routing_tables.get(router_id)
    
    def update_routing_table(self, router_id, routing_table):
        if isinstance(routing_table, RoutingTable):
            self.routing_tables[router_id] = routing_table
    
    def get_graph(self):
        graph = {}
        for router_id in self.routers:
            graph[router_id] = {}
        
        for link in self.get_active_links():
            graph[link.source_router_id][link.destination_router_id] = link.cost
            graph[link.destination_router_id][link.source_router_id] = link.cost
        
        return graph
    
    def __repr__(self):
        return f"Topology(routers={len(self.routers)}, links={len(self.links)})"