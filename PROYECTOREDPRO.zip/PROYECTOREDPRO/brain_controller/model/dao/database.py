"""
Clase Database: maneja la conexión a MySQL para el controlador.
Base de datos: controllerdb
"""

import mysql.connector
from mysql.connector import Error
import logging

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, host, user, password, database):
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self.connection = None
    
    def connect(self):
        try:
            self.connection = mysql.connector.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database
            )
            if self.connection.is_connected():
                logger.info(f"Conectado a la base de datos {self.database}")
                return True
        except Error as e:
            logger.error(f"Error al conectar a la base de datos: {e}")
            return False
        return False
    
    def disconnect(self):
        if self.connection and self.connection.is_connected():
            self.connection.close()
            logger.info("Desconectado de la base de datos")
    
    def execute_query(self, query, params=None):
        try:
            cursor = self.connection.cursor()
            cursor.execute(query, params or ())
            self.connection.commit()
            last_id = cursor.lastrowid
            cursor.close()
            return last_id
        except Error as e:
            logger.error(f"Error al ejecutar query: {e}")
            self.connection.rollback()
            return None
    
    def fetch_all(self, query, params=None):
        try:
            cursor = self.connection.cursor(dictionary=True)
            cursor.execute(query, params or ())
            results = cursor.fetchall()
            cursor.close()
            return results
        except Error as e:
            logger.error(f"Error al ejecutar fetch_all: {e}")
            return []
    
    def fetch_one(self, query, params=None):
        try:
            cursor = self.connection.cursor(dictionary=True)
            cursor.execute(query, params or ())
            result = cursor.fetchone()
            cursor.close()
            return result
        except Error as e:
            logger.error(f"Error al ejecutar fetch_one: {e}")
            return None
    
    def is_connected(self):
        return self.connection and self.connection.is_connected()