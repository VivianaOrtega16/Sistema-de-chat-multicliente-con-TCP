"""
LinkDAO: acceso a datos para la tabla 'links' en controllerdb.
"""

import logging
from ..link import Link

logger = logging.getLogger(__name__)

class LinkDAO:
    def __init__(self, database):
        self.db = database
    
    def create(self, link):
        query = """
        INSERT INTO links (link_id, source_router_id, destination_router_id, cost, status)
        VALUES (%s, %s, %s, %s, %s)
        """
        params = (link.link_id, link.source_router_id, link.destination_router_id, link.cost, link.status)
        result = self.db.execute_query(query, params)
        if result is not None:
            logger.info(f"Link {link.link_id} creado en BD")
            return True
        return False
    
    def update(self, link):
        query = """
        UPDATE links
        SET source_router_id = %s, destination_router_id = %s, cost = %s, status = %s
        WHERE link_id = %s
        """
        params = (link.source_router_id, link.destination_router_id, link.cost, link.status, link.link_id)
        result = self.db.execute_query(query, params)
        if result is not None:
            logger.info(f"Link {link.link_id} actualizado en BD")
            return True
        return False
    
    def update_status(self, link_id, status):
        query = "UPDATE links SET status = %s WHERE link_id = %s"
        params = (status, link_id)
        result = self.db.execute_query(query, params)
        if result is not None:
            logger.info(f"Status de link {link_id} actualizado a {status}")
            return True
        return False
    
    def delete(self, link_id):
        query = "DELETE FROM links WHERE link_id = %s"
        params = (link_id,)
        result = self.db.execute_query(query, params)
        if result is not None:
            logger.info(f"Link {link_id} eliminado de BD")
            return True
        return False
    
    def get_by_id(self, link_id):
        query = "SELECT * FROM links WHERE link_id = %s"
        params = (link_id,)
        row = self.db.fetch_one(query, params)
        if row:
            return Link(
                link_id=row['link_id'],
                source_router_id=row['source_router_id'],
                destination_router_id=row['destination_router_id'],
                cost=row['cost'],
                status=row['status']
            )
        return None
    
    def get_all(self):
        query = "SELECT * FROM links"
        rows = self.db.fetch_all(query)
        links = []
        for row in rows:
            links.append(Link(
                link_id=row['link_id'],
                source_router_id=row['source_router_id'],
                destination_router_id=row['destination_router_id'],
                cost=row['cost'],
                status=row['status']
            ))
        return links
    
    def get_active_links(self):
        query = "SELECT * FROM links WHERE status = 'active'"
        rows = self.db.fetch_all(query)
        links = []
        for row in rows:
            links.append(Link(
                link_id=row['link_id'],
                source_router_id=row['source_router_id'],
                destination_router_id=row['destination_router_id'],
                cost=row['cost'],
                status=row['status']
            ))
        return links
    
    def get_links_by_router(self, router_id):
        query = """
        SELECT * FROM links 
        WHERE (source_router_id = %s OR destination_router_id = %s)
        AND status = 'active'
        """
        params = (router_id, router_id)
        rows = self.db.fetch_all(query, params)
        links = []
        for row in rows:
            links.append(Link(
                link_id=row['link_id'],
                source_router_id=row['source_router_id'],
                destination_router_id=row['destination_router_id'],
                cost=row['cost'],
                status=row['status']
            ))
        return links
    
    def exists(self, link_id):
        query = "SELECT COUNT(*) as count FROM links WHERE link_id = %s"
        params = (link_id,)
        result = self.db.fetch_one(query, params)
        return result and result['count'] > 0