"""
RouterDAO: acceso a datos para la tabla 'router' en controllerdb.
"""

import logging
from ..router import Router

logger = logging.getLogger(__name__)

class RouterDAO:
    def __init__(self, database):
        self.db = database
    
    def create(self, router):
        query = """
        INSERT INTO router (router_id, ip_address, port, status)
        VALUES (%s, %s, %s, %s)
        """
        params = (router.router_id, router.ip_address, router.port, router.status)
        result = self.db.execute_query(query, params)
        if result is not None:
            logger.info(f"Router {router.router_id} creado en BD")
            return True
        return False
    
    def update(self, router):
        query = """
        UPDATE router
        SET ip_address = %s, port = %s, status = %s
        WHERE router_id = %s
        """
        params = (router.ip_address, router.port, router.status, router.router_id)
        result = self.db.execute_query(query, params)
        if result is not None:
            logger.info(f"Router {router.router_id} actualizado en BD")
            return True
        return False
    
    def update_status(self, router_id, status):
        query = "UPDATE router SET status = %s WHERE router_id = %s"
        params = (status, router_id)
        result = self.db.execute_query(query, params)
        if result is not None:
            logger.info(f"Status de router {router_id} actualizado a {status}")
            return True
        return False
    
    def delete(self, router_id):
        query = "DELETE FROM router WHERE router_id = %s"
        params = (router_id,)
        result = self.db.execute_query(query, params)
        if result is not None:
            logger.info(f"Router {router_id} eliminado de BD")
            return True
        return False
    
    def get_by_id(self, router_id):
        query = "SELECT * FROM router WHERE router_id = %s"
        params = (router_id,)
        row = self.db.fetch_one(query, params)
        if row:
            return Router(
                router_id=row['router_id'],
                ip_address=row['ip_address'],
                port=row['port'],
                status=row['status']
            )
        return None
    
    def get_all(self):
        query = "SELECT * FROM router"
        rows = self.db.fetch_all(query)
        routers = []
        for row in rows:
            routers.append(Router(
                router_id=row['router_id'],
                ip_address=row['ip_address'],
                port=row['port'],
                status=row['status']
            ))
        return routers
    
    def get_connected_routers(self):
        query = "SELECT * FROM router WHERE status = 'connected'"
        rows = self.db.fetch_all(query)
        routers = []
        for row in rows:
            routers.append(Router(
                router_id=row['router_id'],
                ip_address=row['ip_address'],
                port=row['port'],
                status=row['status']
            ))
        return routers
    
    def exists(self, router_id):
        query = "SELECT COUNT(*) as count FROM router WHERE router_id = %s"
        params = (router_id,)
        result = self.db.fetch_one(query, params)
        return result and result['count'] > 0