"""
Clase Link: representa un enlace entre dos routers.
"""

class Link:
    def __init__(self, link_id, source_router_id, destination_router_id, cost, status='active'):
        self.link_id = link_id
        self.source_router_id = source_router_id
        self.destination_router_id = destination_router_id
        self.cost = cost
        self.status = status
    
    def __repr__(self):
        return f"Link(id={self.link_id}, {self.source_router_id}->{self.destination_router_id}, cost={self.cost}, status={self.status})"
    
    def __eq__(self, other):
        if isinstance(other, Link):
            return self.link_id == other.link_id
        return False
    
    def __hash__(self):
        return hash(self.link_id)
    
    def to_dict(self):
        return {
            'link_id': self.link_id,
            'source_router_id': self.source_router_id,
            'destination_router_id': self.destination_router_id,
            'cost': self.cost,
            'status': self.status
        }
    
    def is_active(self):
        return self.status == 'active'