"""
Clase Router: representa un router en la topología SDN.
"""

class Router:
    def __init__(self, router_id, ip_address, port, status='disconnected'):
        self.router_id = router_id
        self.ip_address = ip_address
        self.port = port
        self.status = status
        self.neighbors = []
    
    def __repr__(self):
        return f"Router(id={self.router_id}, ip={self.ip_address}, port={self.port}, status={self.status})"
    
    def __eq__(self, other):
        if isinstance(other, Router):
            return self.router_id == other.router_id
        return False
    
    def __hash__(self):
        return hash(self.router_id)
    
    def to_dict(self):
        return {
            'router_id': self.router_id,
            'ip_address': self.ip_address,
            'port': self.port,
            'status': self.status
        }
    
    def add_neighbor(self, neighbor_id):
        if neighbor_id not in self.neighbors:
            self.neighbors.append(neighbor_id)
    
    def remove_neighbor(self, neighbor_id):
        if neighbor_id in self.neighbors:
            self.neighbors.remove(neighbor_id)