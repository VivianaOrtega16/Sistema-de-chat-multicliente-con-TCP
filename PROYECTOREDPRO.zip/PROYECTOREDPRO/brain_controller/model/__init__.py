"""
Módulo de modelos para el BrainController.
Contiene las clases de dominio: Topology, Router, Link, RoutingTable.
"""

from .topology import Topology
from .router import Router
from .link import Link
from .routing_table import RoutingTable

__all__ = ['Topology', 'Router', 'Link', 'RoutingTable']