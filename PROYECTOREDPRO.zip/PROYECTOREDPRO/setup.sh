#!/bin/bash

echo "=========================================="
echo "  SDN Project - Setup Script"
echo "=========================================="
echo ""

# Colores para output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Función para imprimir mensajes
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Verificar Python
echo "Verificando Python..."
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    print_success "Python encontrado: $PYTHON_VERSION"
else
    print_error "Python 3 no está instalado"
    exit 1
fi

# Verificar MySQL
echo ""
echo "Verificando MySQL..."
if command -v mysql &> /dev/null; then
    MYSQL_VERSION=$(mysql --version)
    print_success "MySQL encontrado: $MYSQL_VERSION"
else
    print_warning "MySQL no encontrado. Por favor instala MySQL Server"
fi

# Crear estructura de directorios
echo ""
echo "Creando estructura de directorios..."

mkdir -p brain_controller/model/dao
mkdir -p brain_controller/controller
mkdir -p brain_controller/view

mkdir -p router/model/dao
mkdir -p router/controller
mkdir -p router/view

mkdir -p protocol

mkdir -p logs

print_success "Estructura de directorios creada"

# Crear archivos __init__.py
echo ""
echo "Creando archivos __init__.py..."

touch brain_controller/__init__.py
touch brain_controller/model/__init__.py
touch brain_controller/model/dao/__init__.py
touch brain_controller/controller/__init__.py
touch brain_controller/view/__init__.py

touch router/__init__.py
touch router/model/__init__.py
touch router/model/dao/__init__.py
touch router/controller/__init__.py
touch router/view/__init__.py

touch protocol/__init__.py

print_success "Archivos __init__.py creados"

# Instalar dependencias
echo ""
echo "Instalando dependencias de Python..."

if [ -f "requirements.txt" ]; then
    pip3 install -r requirements.txt
    if [ $? -eq 0 ]; then
        print_success "Dependencias instaladas correctamente"
    else
        print_error "Error al instalar dependencias"
        exit 1
    fi
else
    print_warning "requirements.txt no encontrado. Instalando manualmente..."
    pip3 install mysql-connector-python==8.0.33
    pip3 install dash==2.14.0
    pip3 install plotly==5.17.0
fi

# Verificar instalación de paquetes
echo ""
echo "Verificando instalación de paquetes..."

python3 -c "import mysql.connector" 2>/dev/null
if [ $? -eq 0 ]; then
    print_success "mysql-connector-python instalado"
else
    print_error "mysql-connector-python NO instalado"
fi

python3 -c "import dash" 2>/dev/null
if [ $? -eq 0 ]; then
    print_success "dash instalado"
else
    print_warning "dash NO instalado (opcional para dashboard)"
fi

python3 -c "import plotly" 2>/dev/null
if [ $? -eq 0 ]; then
    print_success "plotly instalado"
else
    print_warning "plotly NO instalado (opcional para dashboard)"
fi

# Crear archivos de configuración de ejemplo
echo ""
echo "Creando archivos de configuración de ejemplo..."

if [ ! -f "brain_controller/config.json" ]; then
    cat > brain_controller/config.json << 'EOF'
{
  "server": {
    "host": "0.0.0.0",
    "tcp_port": 9000,
    "udp_port": 9001
  },
  "database": {
    "host": "localhost",
    "user": "root",
    "password": "your_password",
    "database": "controllerdb"
  },
  "enable_dash": false,
  "dash": {
    "host": "0.0.0.0",
    "port": 8050
  },
  "logging": {
    "level": "INFO"
  }
}
EOF
    print_success "config.json creado para Brain Controller"
else
    print_warning "config.json ya existe para Brain Controller"
fi

if [ ! -f "router/config.json" ]; then
    cat > router/config.json << 'EOF'
{
  "router": {
    "router_id": "R1",
    "port": 5001
  },
  "brain_controller": {
    "host": "127.0.0.1",
    "tcp_port": 9000,
    "udp_port": 9001
  },
  "database": {
    "host": "localhost",
    "user": "root",
    "password": "your_password",
    "database": "routerdb"
  },
  "logging": {
    "level": "INFO"
  }
}
EOF
    print_success "config.json creado para Router"
else
    print_warning "config.json ya existe para Router"
fi

# Instrucciones finales
echo ""
echo "=========================================="
echo "  Setup completado"
echo "=========================================="
echo ""
print_warning "PASOS SIGUIENTES:"
echo ""
echo "1. Edita los archivos de configuración:"
echo "   - brain_controller/config.json"
echo "   - router/config.json"
echo "   Actualiza las contraseñas de MySQL"
echo ""
echo "2. Crea las bases de datos:"
echo "   mysql -u root -p < ControllerRouter.sql"
echo ""
echo "3. Inicia el Brain Controller:"
echo "   cd brain_controller && python3 main.py"
echo ""
echo "4. Inicia los Routers (en terminales separadas):"
echo "   cd router && python3 main.py"
echo ""
print_success "¡Listo para usar!"